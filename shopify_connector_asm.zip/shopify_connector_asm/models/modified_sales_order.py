import logging
import requests
from odoo.exceptions import ValidationError

from datetime import datetime, timedelta
from odoo import fields, models

_logger = logging.getLogger(__name__)

STORE_DOMAIN = 'Hno-pk'
API_KEY = "ef6e6bde2385001ad32c8c133dbaff43"
PASS = "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"


class CustomerShopifyInherit(models.Model):
    _inherit = 'res.partner'

    shopify_customer_id = fields.Char('Shopify Customer ID')


class ProductShopifyInherit(models.Model):
    _inherit = 'product.product'

    shopify_product_id = fields.Char('Shopify Product ID')


class MyMixedInSaleOrder(models.Model):
    _name = 'sale.order'
    _inherit = ['sale.order']

    platform_order_id = fields.Char('Platform Order ID')
    shopify_store_domain = fields.Char('Shopify Store Domain')
    order_id = fields.Char(String="Shopify Order id")
    order_name = fields.Char(String="Shopify Order name")

    def write(self, values):
        _logger.info('FYI: This is happening')
        for rec in self:
            if rec['shopify_store_domain'] != '':
                print('thinks we should let know shopify know...maybe')
                # shopify_store_domain = rec['shopify_store_domain']
                shopify_store_domain = STORE_DOMAIN
                # shopify_order_id = rec['platform_order_id']
                ### CANCELLED CASE ###
                print(rec['state'])
                print(values)
                # if 'state' in values and values['state'] == 'cancel':
                print('thinks we should cancel the order')
                shopify_store = self.env['shopify_connector.store'].search([['shop_name', '=', shopify_store_domain]])
                print("SSSSSSSSSSSSSSSSSSSSSSSS")
                print(shopify_store)
                api_key = shopify_store['api_key'] or API_KEY
                password = shopify_store['password'] or PASS
                # order_shop_url = "https://" + str(api_key) + ":" + str(password) +"@" + str(shopify_store_domain) + ".myshopify.com/admin/api/2020-10/orders/" + str(shopify_order_id) + "/cancel.json"
                order_shop_url = "https://" + str(api_key) + ":" + str(password) + "@" + str(
                    shopify_store_domain) + ".myshopify.com/admin/api/2020-10/orders/3656464728111.json"

                headers = {
                    'X-Shopify-Access-Token': password,
                    'Content-Type': "application/json"
                }
                # no refund
                # get rekt
                cancel_json = {}
                response = requests.get(order_shop_url, headers=headers)
                print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
                print(response)
                print(response.json())
            record = super(MyMixedInSaleOrder, self).write(values)
            return record

    def shopify_product_variant_fetch(self, product_name, product_variant_id, product_variant_price):
        api_key = "ef6e6bde2385001ad32c8c133dbaff43"
        password = "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"
        shopify_store_domain = "Hno-pk"
        headers = {
            'X-Shopify-Access-Token': password,
            'Content-Type': "application/json"
        }
        product_variant_shop_url = "https://" + str(api_key) + ":" + str(password) + "@" + str(
            shopify_store_domain) + ".myshopify.com//admin/api/2021-01/variants/" + str(product_variant_id) + ".json"
        my_product_variant = {}
        # --- error check for product variant
        try:
            response = requests.get(product_variant_shop_url, headers=headers)
            my_product_variant = response.json()
        except Exception as e:
            raise ValidationError(e)
        if my_product_variant:
            my_product_variant_single = my_product_variant['variant']
            product_weight = my_product_variant_single['weight']
            product_weight_unit = my_product_variant_single['weight_unit']

            print(product_weight_unit)
            if product_weight_unit == 'g':
                product_weight = product_weight / 1000
            if product_weight_unit == 'kg':
                product_weight = product_weight
            if product_weight_unit == 'oz':
                product_weight = product_weight / 35.274
            if product_weight_unit == 'lb':
                product_weight = product_weight / 2.205
            print("product weight converted: ", product_weight)
            shopify_product = self.env['product.product'].create({
                'name': product_name,
                'shopify_product_id': my_product_variant_single['id'],
                'standard_price': my_product_variant_single['price'],
                'weight': product_weight,
                'lst_price': my_product_variant_single['compare_at_price'],
                'barcode': my_product_variant_single['barcode'],
                'default_code': my_product_variant_single['sku']
            })
            return shopify_product

    def shopify_customer_fetch(self, customer_id):
        api_key = "ef6e6bde2385001ad32c8c133dbaff43"
        password = "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"
        shopify_store_domain = "Hno-pk"
        headers = {
            'X-Shopify-Access-Token': password,
            'Content-Type': "application/json"
        }
        customer_shop_url = "https://" + str(api_key) + ":" + str(password) + "@" + str(
            shopify_store_domain) + ".myshopify.com/admin/api/2021-01/customers/" + str(customer_id) + ".json"
        my_customer = {}

        # --- error check for customer
        try:
            response = requests.get(customer_shop_url, headers=headers)
            print("response status ", response.status_code)
            my_customer = response.json()
        except Exception as e:
            raise ValidationError(e)
        if my_customer:
            my_customer_single = my_customer['customer']
            customer_name = my_customer_single['first_name'] + " " + my_customer_single['last_name']
            my_customer_addresses = my_customer_single['default_address']
            shopify_customer = self.env['res.partner'].create({
                'shopify_customer_id': customer_id,
                'name': customer_name,
                'phone': my_customer_single['phone'],
                'email': my_customer_single['email'],
                'street': my_customer_addresses['address1'],
                'city': my_customer_addresses['city'],
                'zip': my_customer_addresses['zip'],
            })
            return shopify_customer

    def get_specific_order(self):
        print("job running")
        api_key = "ef6e6bde2385001ad32c8c133dbaff43"
        password = "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"
        shopify_store_domain = "Hno-pk"
        headers = {
            'X-Shopify-Access-Token': password,
            'Content-Type': "application/json"
        }

        # --- Job execution time check
        job_cron = self.env['ir.cron'].search([('name', "=", "Shopify Integration Job")])
        job_exec_date_mod = job_cron.lastcall
        if job_exec_date_mod:
            print("msg: job executed before")
            job_exec_date_mod = str(job_cron.lastcall - timedelta(days=3))
            job_exec_date_mod = job_exec_date_mod.split(" ", 1)[0]
            order_shop_url = "https://" + str(api_key) + ":" + str(password) + "@" + str(
                shopify_store_domain) + ".myshopify.com/admin/api/2021-01/orders.json?created_at_min=" + str(
                job_exec_date_mod) + "T00:00:59+05:00"

        else:
            print("msg: job first time execution")
            order_shop_url = "https://" + str(api_key) + ":" + str(password) + "@" + str(
                shopify_store_domain) + ".myshopify.com/admin/api/2021-01/orders.json?status=any"
        orders = {}

        # --- error check on order api response
        try:
            response = requests.get(order_shop_url, headers=headers)
            orders = response.json()

        except Exception as e:
            raise ValidationError(e)
        if orders:
            for order in orders['orders']:
                order_id = order['id']
                order_name = order['name']
                order_customer = order['customer']
                order_customer_id = order_customer['id']
                customer_exist = self.env['res.partner'].search([('shopify_customer_id', '=', order_customer_id)])

                # --- check customer exist or not
                if not customer_exist:
                    customer_exist = self.shopify_customer_fetch(order_customer_id)
                order_datetime = order['created_at']
                cur_time = order_datetime
                cur_time = cur_time.replace("T", " ")
                actual_time = cur_time.split("+", 1)[0]
                fmt = "%Y-%m-%d %H:%M:%S"
                formatted_time = datetime.strptime(actual_time, fmt)
                order_exist = self.env['sale.order'].search([('order_id', '=', order_id)])

                # -- check order exist or not
                if not order_exist:
                    shopify_order = self.create({
                        'partner_id': customer_exist.id,
                        'order_id': order_id,
                        'order_name': order_name,
                        'date_order': formatted_time,
                    })
                    order_lines = order['line_items']
                    for obj in order_lines:
                        product_exist = self.env['product.product'].search(
                            [('shopify_product_id', '=', obj['variant_id'])])

                        # ---  check if product in orderline exist or not
                        if not product_exist:
                            product_exist = self.shopify_product_variant_fetch(obj['name'], obj['variant_id'],
                                                                               obj['price'])
                        self.env['sale.order.line'].create({
                            'product_id': product_exist.id,

                            'name': product_exist.name,
                            'product_uom_qty': obj['quantity'],
                            'price_unit': product_exist.standard_price,
                            'order_id': shopify_order.id,
                        })
        print("msg: order already exists, no new order added in shopify ")
