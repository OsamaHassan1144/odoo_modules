# -*- coding: utf-8 -*-
# from odoo import http


# class VisioProductColor(http.Controller):
#     @http.route('/visio_product_color/visio_product_color/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/visio_product_color/visio_product_color/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('visio_product_color.listing', {
#             'root': '/visio_product_color/visio_product_color',
#             'objects': http.request.env['visio_product_color.visio_product_color'].search([]),
#         })

#     @http.route('/visio_product_color/visio_product_color/objects/<model("visio_product_color.visio_product_color"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('visio_product_color.object', {
#             'object': obj
#         })
