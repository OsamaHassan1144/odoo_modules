# -*- coding: utf-8 -*-

from odoo import models, fields


class visio_product_inherit(models.Model):
    _inherit = 'product.product'
    _description = 'adding color field to product'

    product_color = fields.Many2one('product.color', 'color_name')

    top_bg_color = fields.Many2one('product.color', 'color_name')
    top_text_color = fields.Many2one('product.color', 'color_name')
    bottom_bg_color = fields.Many2one('product.color', 'color_name')
    bottom_text_color = fields.Many2one('product.color', 'color_name')


class visio_product_color(models.Model):
    _name = 'product.color'
    _description = 'assign color to product'
    _rec_name = 'color_name'

    color_name = fields.Char(String="Color", store=True)
    color_html_code = fields.Char(String="Color's Html Code", store=True)
