# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProductInherit(models.Model):
    _inherit = "product.product"

#     qty_available_all_locations = fields.Float(
#         'Quantity On Hand Sum', compute='_compute_quantities_loc_sec',
#         digits='Product Unit of Measure',
#         help="Current quantity of products.\n"
#              "In a context with a single Stock Location, this includes "
#              "goods stored at this Location, or any of its children.\n"
#              "In a context with a single Warehouse, this includes "
#              "goods stored in the Stock Location of this Warehouse, or any "
#              "of its children.\n"
#              "stored in the Stock Location of the Warehouse of this Shop, "
#              "or any of its children.\n"
#              "Otherwise, this includes goods stored in any Stock Location "
#              "with 'internal' type.")
#
#
#     @api.depends('stock_quant_ids.product_id','stock_quant_ids.inventory_quantity')
#     def _compute_quantities_loc_sec(self):
#         if self.stock_quant_ids:
#             for stocks in self.stock_quant_ids:
#                 if stocks.location_id.usage == 'internal':
#                     self.qty_available_all_locations += stocks.inventory_quantity
#         else:
#             self.qty_available_all_locations = 0
#
#
    # Be aware that the exact same function exists in product.template
    def action_open_quants(self):
        domain = [('product_id', 'in', self.ids)]
        hide_location = not self.user_has_groups('stock.group_stock_multi_locations')
        hide_lot = all([product.tracking == 'none' for product in self])
        self = self.with_context(hide_location=hide_location, hide_lot=hide_lot)

        # If user have rights to write on quant, we define the view as editable.
        if self.user_has_groups('stock.group_stock_manager'):
            self = self.with_context(inventory_mode=True)
            # Set default location id if multilocations is inactive
            if not self.user_has_groups('stock.group_stock_multi_locations'):
                user_company = self.env.company
                warehouse = self.env['stock.warehouse'].search(
                    [('company_id', '=', user_company.id)], limit=1
                )
                if warehouse:
                    self = self.with_context(default_location_id=warehouse.lot_stock_id.id)
        # Set default product id if quants concern only one product
        if len(self) == 1:
            self = self.with_context(
                default_product_id=self.id,
                single_product=True
            )
        else:
            self = self.with_context(product_tmpl_id=self.product_tmpl_id.id)
        ctx = dict(self.env.context)
        ctx.update({'no_at_date': True, 'search_default_internal_loc': True})
        return self.env['stock.quant'].with_context(ctx)._get_quants_action(domain)



class ProductTemplateInherit(models.Model):
    _inherit = "product.template"

    qty_available_all_locations = fields.Float(
        'Quantity On Hand Sum', compute='_compute_quantities_loc_sec',
        digits='Product Unit of Measure',
        help="Current quantity of products.\n"
             "In a context with a single Stock Location, this includes "
             "goods stored at this Location, or any of its children.\n"
             "In a context with a single Warehouse, this includes "
             "goods stored in the Stock Location of this Warehouse, or any "
             "of its children.\n"
             "stored in the Stock Location of the Warehouse of this Shop, "
             "or any of its children.\n"
             "Otherwise, this includes goods stored in any Stock Location "
             "with 'internal' type.")


    @api.depends('product_variant_ids')
    def _compute_quantities_loc_sec(self):
        product = self.env['product.product'].search([('name','=',self.name)])
        if product:
            stocks = self.env['stock.quant'].search([('product_id','=',product.id)])
        if stocks:
            for stock in stocks:
                if stock.location_id.usage == 'internal':
                    self.qty_available_all_locations += stock.inventory_quantity
        else:
            self.qty_available_all_locations = 0
