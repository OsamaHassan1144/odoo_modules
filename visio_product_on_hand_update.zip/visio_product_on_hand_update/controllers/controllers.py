# -*- coding: utf-8 -*-
# from odoo import http


# class VisioProductOnHandUpdate(http.Controller):
#     @http.route('/visio_product_on_hand_update/visio_product_on_hand_update/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/visio_product_on_hand_update/visio_product_on_hand_update/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('visio_product_on_hand_update.listing', {
#             'root': '/visio_product_on_hand_update/visio_product_on_hand_update',
#             'objects': http.request.env['visio_product_on_hand_update.visio_product_on_hand_update'].search([]),
#         })

#     @http.route('/visio_product_on_hand_update/visio_product_on_hand_update/objects/<model("visio_product_on_hand_update.visio_product_on_hand_update"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('visio_product_on_hand_update.object', {
#             'object': obj
#         })
