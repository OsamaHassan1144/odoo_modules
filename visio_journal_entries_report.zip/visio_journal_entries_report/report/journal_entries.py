from odoo import models, api
from odoo.exceptions import UserError


class JournalEntriesReport(models.AbstractModel):
    _name = 'visio_journal_entries_report.journal_entries_report'
    _description = 'Journal Entries Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'data': data,
        }
