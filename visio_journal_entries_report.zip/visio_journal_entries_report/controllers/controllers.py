# -*- coding: utf-8 -*-
# from odoo import http


# class VisioJournalEntriesReport(http.Controller):
#     @http.route('/visio_journal_entries_report/visio_journal_entries_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/visio_journal_entries_report/visio_journal_entries_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('visio_journal_entries_report.listing', {
#             'root': '/visio_journal_entries_report/visio_journal_entries_report',
#             'objects': http.request.env['visio_journal_entries_report.visio_journal_entries_report'].search([]),
#         })

#     @http.route('/visio_journal_entries_report/visio_journal_entries_report/objects/<model("visio_journal_entries_report.visio_journal_entries_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('visio_journal_entries_report.object', {
#             'object': obj
#         })
