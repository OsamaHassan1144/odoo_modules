# -*- coding: utf-8 -*-
# from odoo import http


# class FetchCusData(http.Controller):
#     @http.route('/fetch_cus_data/fetch_cus_data/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/fetch_cus_data/fetch_cus_data/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('fetch_cus_data.listing', {
#             'root': '/fetch_cus_data/fetch_cus_data',
#             'objects': http.request.env['fetch_cus_data.fetch_cus_data'].search([]),
#         })

#     @http.route('/fetch_cus_data/fetch_cus_data/objects/<model("fetch_cus_data.fetch_cus_data"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('fetch_cus_data.object', {
#             'object': obj
#         })
