# -*- coding: utf-8 -*-
from odoo import models, fields, api


class fetch_cus_data(models.Model):
    _name = 'pos.order_fetch'

    @api.model
    def get_orders_customer(self, customer_name):
        res = self.env['pos.order'].search([('partner_id.name', '=', customer_name)])
        list_order = []
        my_id = 1
        my_item = ""
        for x in res:
            date_time_str = x.date_order
            date_time_str_d = date_time_str.strftime("%m/%d/%Y")
            date_time_str_t = date_time_str.strftime("%H:%M")
            for y in x.lines:
                my_item = y.product_id.display_name + ' , ' + my_item
            val_list = {
                'id': my_id,
                'dates': date_time_str_d,
                'times': date_time_str_t,
                'name': x.pos_reference,
                'customer_name': x.partner_id.name,
                'items': my_item,

            }
            list_order.append(val_list)
            my_id += 1
            my_item = ""
        return list_order

    @api.model
    def get_specific_products(self, order_name):
        res = self.env['pos.order'].search([('pos_reference', '=', order_name)])
        product_l = []
        for a in res.lines:
            print(a)
            pro_list = {
                'product_id': a.product_id.id,
                'price': a.price_subtotal,
                'quantity': a.qty,
                'discount': a.discount or False,
                'discount_fixed': a.discount_fixed or False,
            }
            product_l.append(pro_list)

        return product_l
