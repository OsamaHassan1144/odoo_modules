odoo.define('pos_fetch_data.pos_orders_queue', function (require) {
    "use strict";

//    var screens = require('point_of_sale.screens');
//    var gui = require('point_of_sale.gui');
//    var core = require('web.core');
//    var rpc = require('web.rpc');
//    var session = require('web.session');
//    var models = require('point_of_sale.models');
//    var PopupWidget = require('point_of_sale.popups');
//    var ScreenWidget = screens.ScreenWidget;
//    var ClientListScreenWidget = screens.ClientListScreenWidget;
//    var Backbone = window.Backbone;
//    var longpolling = require('pos_longpolling');
//    var QWeb = core.qweb;
//    var _t = core._t;

    var core = require('web.core');
    var rpc = require('web.rpc');
    var screens = require('point_of_sale.screens');
    var models = require('point_of_sale.models');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');

    var QWeb = core.qweb;
    var _t = core._t;



var OrdersQueueScreenWidget = screens.ScreenWidget.extend({
    template: 'OrdersQueueScreenWidget',

    show: function(){
        console.log('i bill fetch');
        var self = this;
        this._super();
        var customer_name = this.pos.get_client().name;
        console.log("customer_name =>",customer_name);
        rpc.query({
                model: 'pos.order_fetch',
                method: 'get_orders_customer',
                args: [customer_name],
            }).then(function(datas) {
                self.render_list(datas);
            }).catch(function(reason) {
                var error = reason.message;
         });
        $('body').one('click', '.set-default-order', function() {
               console.log('i select');
               console.log('lol',$(this).data("ordername"))
               self.line_select(event,$(this),parseInt($(this).data('id')),String($(this).data("ordername")));

        });
        this.$('.back').off().click(function(){
            console.log("i back");
            self.gui.back();

        });

    },
    render_list: function(datas){
        var contents = this.$el[0].querySelector('.ordersqueue-list-contents');
        var temp="";
        contents.innerHTML = "";
        for(var i = 0; i < datas.length; i++){
            var order   = datas[i];
            var order_line_html = QWeb.render('PosOrdersQueueLine',{widget: this, order:order});
            var order_line = document.createElement('tbody');
            order_line.innerHTML = order_line_html;
            order_line = order_line.childNodes[1];
            contents.appendChild(order_line);
        }

    },
    line_select: function(event,$line,id,ordername){
            var self = this;
            var current_order = self.pos.get_order();
            var data_order = ordername;
            var nr = $line[0];
            rpc.query({
                model: 'pos.order_fetch',
                method: 'get_specific_products',
                args: [data_order],
            }).then(function(l) {

             for(var i = 0; i < l.length; i++){
                var order   = l[i];
                var product = self.pos.db.get_product_by_id(order.product_id);
                console.log("product",product)
                current_order.add_product(product,{ quantity: order.quantity,  discount: order.discount });
            }
            current_order.empty();
            }).catch(function(reason) {
                var error = reason.message;
         });
            this.gui.show_screen('products');
         event.stopImmediatePropagation();

        },

});
gui.define_screen({ name:'ordersqueue', widget: OrdersQueueScreenWidget, });

var OrdersQueueButton = screens.ActionButtonWidget.extend({
    template: 'ordersqueue_button',
     button_click: function(){
        var self = this;
        console.log('pos.get_order() =>',self.pos.get_order());

        var change_name = self.pos.get_order().changed.client;
        var attr_name = self.pos.get_order().attributes.client;
        if( change_name || attr_name)
        {
            self.ordersqueue_function();
        }
        else
        {
            alert("Select a customer");
        }

    },

    ordersqueue_function: function(){
        this.gui.show_screen('ordersqueue');

    }

});
    screens.define_action_button({
        'name': 'ordersqueue_button',
        'widget': OrdersQueueButton,
        });


});