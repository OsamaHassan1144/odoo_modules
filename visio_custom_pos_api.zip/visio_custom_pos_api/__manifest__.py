# -*- coding: utf-8 -*-
{
    'name': "Custom POS connector api ",

    'summary': """
        This module allows user to connect odoo's POS to customized POS. """,

    'description': """
       Custom POS Module v1.0 (beta) with :
            1. api  - connects and provides all necessary data for custom pos to work properly. 
        
          UPDATES
    
        [7th-July-2021]
                * Module Working version (beta) was installed and running.  
    """,

    'author': "Osama Hassan @Visiomate",
    'website': "https://visiomate.com/about.html",
    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'point_of_sale', 'pos_restaurant'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'demo/demo.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}
