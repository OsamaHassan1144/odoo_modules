# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.http import request
import psycopg2
from psycopg2 import Error


class DbConnectionLogin(models.Model):
    _name = 'db.connects'

    @api.model
    def connect_external_db(self):
        connection = None
        odoo_info = request.session

        try:
            # Connect to an existing database
            connection = psycopg2.connect(user="postgres",
                                          password="12345",
                                          host="localhost",
                                          port="5432",
                                          database="pos_login")

            # Create a cursor to perform database operations
            cursor = connection.cursor()
            cursor.execute("Select email FROM login_data ")
            records = cursor.fetchall()

            res = any(x[0] == odoo_info.login for x in records)
            if not res:
                insert_query = """ INSERT INTO login_data (database, email) VALUES (%s,%s);"""
                cursor.execute(insert_query, (odoo_info.db, odoo_info.login))
                connection.commit()
                print("1 Record inserted successfully")

            # if not any(odoo_info.email in records):
            #     insert_query = """ INSERT INTO login_data (database, email) VALUES (%s,%s);"""
            #     cursor.execute(insert_query, (odoo_info.db, odoo_info.login))
            #     connection.commit()
            #     print("1 Record inserted successfully")

            print(records)
            # Fetch result

            # Executing a SQL query to insert data into  table
            # insert_query = """ INSERT INTO login_data (database, email) VALUES (%s,%s);"""
            # cursor.execute(insert_query, (odoo_info.db, odoo_info.login))
            # connection.commit()
            # print("1 Record inserted successfully")

            # Executing a SQL query to delete table
            # delete_query = """Delete from login_data """
            # cursor.execute(delete_query)
            # connection.commit()
            # count = cursor.rowcount
            # print(count, "Record deleted successfully ")

            # # Print PostgreSQL details
            # print("PostgreSQL server information")
            # print(connection.get_dsn_parameters(), "\n")
            # Executing a SQL query
            cursor.execute("Select * FROM login_data ")
            # Fetch result
            record = cursor.fetchall()
            print("You are connected to - ", record, "\n")

        except (Exception, Error) as error:
            print("Error while connecting to PostgreSQL", error)
        finally:
            if connection:
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")

    # def json_rpc(url, method, params):
    #     data = {
    #         "jsonrpc": "2.0",
    #         "method": method,
    #         "params": params,
    #         "id": random.randint(0, 1000000000),
    #     }
    #     req = urllib.request.Request(url=url, data=json.dumps(data).encode(), headers={
    #         "Content-Type": "application/json",
    #     })
    #     reply = json.loads(urllib.request.urlopen(req).read().decode('UTF-8'))
    #     if reply.get("error"):
    #         raise Exception(reply["error"])
    #     return reply["result"]


class PosTypeSelection(models.Model):
    _inherit = 'pos.config'

    pos_type_sel = fields.Selection(
        [('simple', 'Simple'), ('drivethru', 'Drive Thru'), ('oil_rest_hotel', 'Oil/Restaurant/Hotel')],
        string="Pos Type", default='simple')


class TableOrderLimit(models.Model):
    _inherit = 'restaurant.table'

    multiple_order = fields.Boolean(String="Multiple Order\'s creation table wise", default=True, store=True)
