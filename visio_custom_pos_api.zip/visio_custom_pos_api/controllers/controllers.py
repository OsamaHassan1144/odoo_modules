# # -*- coding: utf-8 -*-
# from odoo import http, _
# from odoo.http import request
# import json
# import psycopg2
# from psycopg2 import Error
# import werkzeug.urls
# import odoo
# import urllib
# import logging
# import xmlrpc.client
#
# from odoo.addons.web.controllers import main
#
# _logger = logging.getLogger(__name__)
#
#
# class PosCustom(http.Controller):
#
#     @http.route('/api/call', auth='user')  # api
#     def pos_fetch(self):
#         info = xmlrpc.client.ServerProxy('https://localhost:8069')
#         # print('stuckkk', info._ServerProxy__host)
#
#     @http.route('/api/pos_info/<uid>', auth='user')  # pos config info api
#     def pos_info_fetch(self, uid):
#         var_dict = {}
#         type_pos = ''
#         var_list = []
#         pos_info = http.request.env['pos.config'].search([('write_uid.id', '=', uid)])
#         if pos_info:
#             for x in pos_info:
#                 if x.module_pos_restaurant and x.is_table_management:
#                     type_pos = 'rt'
#                 elif x.module_pos_restaurant and not x.is_table_management:
#                     type_pos = 'rwt'
#                 else:
#                     type_pos = 's'
#
#                 var_dict = {
#                     'id': x.id,
#                     'name': x.name,
#                     'pos_type': type_pos,
#                 }
#                 var_list.append(var_dict)
#
#         else:
#             _logger.error('Invalid Shop / No data.')
#         print(var_list)
#         jsonStr = json.dumps(var_list)
#         return jsonStr
#
#     @http.route('/api/floor&table_info/<config_id>', auth='user')  # info api
#     def floors_tables_fetch(self, config_id):
#
#         pos_info = http.request.env['pos.config'].search([('id', '=', config_id)])
#         floors = http.request.env['restaurant.floor'].search([('id', 'in', pos_info.floor_ids.ids)])
#         tables = http.request.env['restaurant.table'].search([('id', 'in', pos_info.floor_ids.table_ids.ids)])
#         tables_list = []
#         floors_list = []
#         tables_dict = {}
#         floors_dict = {}
#         if tables:
#             for x in tables:
#                 tables_dict = {
#                     'name': x.name,
#                     'seats': x.seats,
#                     'color': x.color,
#                     'h_position': x.position_h,
#                     'v_position': x.position_v,
#                     'width': x.width,
#                     'height': x.height,
#                 }
#                 tables_list.append(tables_dict)
#         else:
#             tables_list = []
#         if floors:
#             for y in floors:
#                 tables = http.request.env['restaurant.table'].search([('id', 'in', y.table_ids.ids)])
#                 if tables:
#                     tables_list = []
#                     for x in tables:
#                         tables_dict = {
#                             'name': x.name,
#                             'seats': x.seats,
#                         }
#                         tables_list.append(tables_dict)
#
#                 floors_dict = {
#                     'id': y.id,
#                     'floor_name': y.name,
#                     'tables': tables_list,
#                 }
#                 floors_list.append(floors_dict)
#
#
#         else:
#             _logger.error('ERROR: No Records found ! Given POS isn\'t a restaurant or doesn\'t have table management ')
#             floors_list = ['ERROR: No Records found ! Given POS isn\'t a restaurant or doesn\'t have table management ']
#         print(floors_list)
#         jsonStr = json.dumps(floors_list)
#         return jsonStr
#
#     @http.route('/api/config_info/<config_id>', auth='user')  # pos config info api
#     def pos_type_fetch(self, config_id):
#         val_list = {}
#
#         pos_payments = []
#         allowed_categ_arr = []
#         cate_list = {}
#         allowed_categ = []
#         worker_ids = []
#         pos_info = http.request.env['pos.config'].search([('id', '=', config_id)])
#         if pos_info:
#             # if pos_info.worker_info:
#             #     for x in pos_info.worker_info.id:
#             #         worker_ids.append(x)
#             # else:
#             #     pos_info.worker_info = False
#             if pos_info.iface_available_categ_ids:
#                 for z in pos_info.iface_available_categ_ids.ids:
#                     allowed_categ.append(z)
#             if pos_info.payment_method_ids:
#                 for y in pos_info.payment_method_ids:
#                     payment_methods = {
#                         'id': y.id,
#                         'name': y.name,
#                     }
#                     pos_payments.append(payment_methods)
#             allowed_categ_info = http.request.env['pos.category'].search([('id', 'in', allowed_categ)])
#             if allowed_categ_info:
#                 for x in allowed_categ_info:
#                     cate_list = {
#                         'id': x.id,
#                         'name': x.name,
#                     }
#                     allowed_categ_arr.append(cate_list)
#
#             val_list = {
#                 'config_id': pos_info.id,
#                 'current_user_id': pos_info.current_user_id.id,
#                 'limit_categories': pos_info.limit_categories,
#                 'worker_info': worker_ids or False,
#                 'available_categories': allowed_categ_arr or False,
#                 'is_table_management': pos_info.is_table_management,
#                 'order_type_feat': pos_info.order_type_feat or False,
#                 'points_cap': pos_info.points_cap or False,
#                 'orderline_notes': pos_info.iface_orderline_notes,
#                 'payment_method': pos_payments or False,
#             }
#         else:
#             _logger.error('Invalid Shop / No data.')
#         print(val_list)
#         jsonStr = json.dumps(val_list)
#         return jsonStr
#
#     @http.route('/api/customers/<company_name>', auth='user', cors='*')  # partner api from this.partner
#     def customer_fetch(self, company_name):
#         print("acquiring customers for your pos")
#         partners = []
#         customer_info = {}
#         cust_data = http.request.env['res.partner'].search([])
#         if cust_data:
#             for x in cust_data:
#                 # formatting address according this.partners
#                 if x.street:
#                     street_str = x.street
#                 else:
#                     street_str = ' '
#                 if x.zip:
#                     zip_str = x.zip
#                 else:
#                     zip_str = ' '
#                 if x.city:
#                     city_str = x.city
#                 else:
#                     city_str = ' '
#                 if x.state_id.display_name:
#                     state_str = x.state_id.display_name
#                 else:
#                     state_str = ' '
#                 if x.country_id.name:
#                     country_str = x.country_id.name
#                 else:
#                     country_str = ' '
#                 if x.image_1920:
#                     image_base = x.image_1920
#                     image_final = "data:image/jpeg;base64," + image_base.decode()
#                 else:
#                     image_final = False
#                 customer_address = street_str + ', ' + zip_str + ', ' + city_str + ', ' + state_str + ', ' + country_str
#                 customer_info = {'address': customer_address or False,
#                                  'barcode': x.barcode or False,
#                                  'id': x.id or False,
#                                  'city': x.city or False,
#                                  'car_num': x.car_num or False,
#                                  'country_id': [x.country_id.id, x.country_id.name] or False,
#                                  'email': x.email or False,
#                                  'name': x.name or False,
#                                  'phone': x.phone or False,
#                                  'image': image_final,
#                                  'points_earned': x.points_earned or False,
#                                  'property_account_position_id': [x.property_account_position_id.id,
#                                                                   x.property_account_position_id.display_name] or False,
#                                  'property_product_pricelist': [x.property_product_pricelist.id,
#                                                                 x.property_product_pricelist.display_name] or False,
#                                  'state_id': [x.state_id.id, x.state_id.display_name] or False,
#                                  'street': x.street or False,
#                                  'vat': x.vat or False,
#                                  'write_date': x.write_date.strftime('%Y-%m-%d %H:%M:%S') or False,
#                                  'zip': x.zip or False,
#                                  }
#                 partners.append(customer_info)
#         print('returning array of customers', partners)
#         jsonStr = json.dumps(partners)
#         return jsonStr
#
#     @http.route('/api/instructions', auth='user')  # instructions api
#     def instructions_fetch(self):
#         print("acquiring instructions for your pos")
#         instructions = []
#         instruction_info = {}
#         instruct_data = http.request.env['pos.message'].search([])
#         if instruct_data:
#             for x in instruct_data:
#                 instruction_info = {
#                     'id': x.id,
#                     'message_content': x.msg_text,
#                 }
#                 instructions.append(instruction_info)
#         print('returning array of instructions', instructions)
#         jsonStr = json.dumps(instructions)
#         return jsonStr
#
#     @http.route('/api/salesman', auth='user')  # salesman api
#     def salesman_fetch(self):
#         print("acquiring salesman for your pos")
#         salesman = []
#         salesman_info = {}
#         salesmen_data = http.request.env['pos.workers.salesmen'].search([])
#         if salesmen_data:
#             for x in salesmen_data:
#                 salesman_info = {
#                     'id': x.id,
#                     'name': x.salesmen_name,
#                 }
#                 salesman.append(salesman_info)
#         print('returning array of instructions', salesman)
#         jsonStr = json.dumps(salesman)
#         return jsonStr
#
#     @http.route('/api/order_history/<customer_name>', auth='user')  # fetch customer order history api
#     def order_history_fetch(self, customer_name):
#         print("acquiring order_history of customer")
#         res = http.request.env['pos.order'].search([('partner_id.name', '=', customer_name)])
#         list_order = []
#         my_id = 1
#         my_item = ""
#         for x in res:
#             date_time_str = x.date_order
#             date_time_str_d = date_time_str.strftime("%m/%d/%Y")
#             date_time_str_t = date_time_str.strftime("%H:%M")
#             for y in x.lines:
#                 my_item = y.product_id.display_name + ' , ' + my_item
#             val_list = {
#                 'id': my_id,
#                 'date': date_time_str_d,
#                 'time': date_time_str_t,
#                 'name': x.pos_reference,
#                 'customer_name': x.partner_id.name,
#                 'items': my_item,
#             }
#             list_order.append(val_list)
#             my_id += 1
#             my_item = ""
#         print('returning array of instructions', list_order)
#         jsonStr = json.dumps(list_order)
#         return jsonStr
#
#     @http.route('/api/products/<config_id>', auth='user')  # products KDS api
#     def product_fetch(self, config_id):
#         products_allow_pos = http.request.env['pos.config'].search([('id', '=', config_id)])
#
#         allowed_categories = []
#         products = []
#
#         product_info = {}
#
#         if products_allow_pos:
#             for x in products_allow_pos.iface_available_categ_ids.ids:
#                 allowed_categories.append(x)
#             print('allowed categories', allowed_categories)
#         products_pos = http.request.env['product.product'].search(
#             [('available_in_pos', '=', True), ('pos_categ_id', 'in', allowed_categories)])
#         if products_pos:
#             for y in products_pos:
#                 parent_categories = []
#                 instructions = []
#                 if y.instruction_select:
#                     for a in y.instruction_select.ids:
#                         instructions.append(a)
#                 print('instructions')
#                 if y.parent_int_categ:
#                     for b in y.parent_int_categ.ids:
#                         parent_categories.append(b)
#                 if y.image_1920:
#                     image_base = y.image_1920
#                     image_final = "data:image/jpeg;base64," + image_base.decode()
#                 else:
#                     image_final = False
#                 products_avail = {
#                     'barcode': y.barcode,
#                     'default_code': y.default_code,
#                     'description': y.description,
#                     'description_sale': y.description_sale,
#                     'display_name': y.display_name,
#                     'distinct_product': y.distinct_product or False,
#                     'id': y.id,
#                     'image': image_final,
#                     'instruction_select': instructions or False,
#                     'lst_price': y.lst_price,
#                     'parent_int_categ': parent_categories or False,
#                     'pos_categ_id': [y.pos_categ_id.id, y.pos_categ_id.display_name],
#                     'product_color': [y.product_color.id, y.product_color.display_name] or False,
#                     'product_tmpl_id': y.product_tmpl_id.id,
#                     'redeem_points': y.redeem_points or False,
#                     'reward_points': y.reward_points or False,
#                     'seq_num': y.seq_num or False,
#                     'standard_price': y.standard_price,
#                     'taxes_id': [y.taxes_id.id],
#                     'tracking': y.tracking,
#                     'uom_id': [y.uom_id.id, y.uom_id.display_name],
#                 }
#                 products.append(products_avail)
#         print('products', products)
#         jsonStr = json.dumps(products)
#         return jsonStr
#
#     @http.route('/api/cars', auth='user')  # cars api
#     def cars_fetch(self, car_id):
#         print("acquiring cars for your pos")
#         cars = []
#         car_info = {}
#         cars_data = http.request.env['user.cars'].search([])
#         if cars_data:
#             for x in cars_data:
#                 car_info = {
#                     'car_brand': x.car_brand.id,
#                     'car_id': x.id,
#                     'car_model': x.car_model,
#                     'car_status': x.car_status,
#                     'name': x.name,
#                     'partner_id': x.partner_id.id,
#                     'partner_mobile': x.partner_mobile,
#                     'car_reading_per_day': x.car_reading_per_day,
#                     'current_reading': x.current_reading,
#                     'vehicle_no': x.vehicle_no,
#                     'km_for_next_service': x.km_for_next_service,
#                     'car_reading_ids': x.car_reading_ids.ids,
#                 }
#                 cars.append(car_info)
#         print('returning array of cars', cars)
#         jsonStr = json.dumps(cars)
#         return jsonStr
#
#     @http.route('/api/car_info/<car_id>', auth='user')  # car by id api
#     def car_fetch(self, car_id):
#         print("acquiring car by id for your pos")
#         cars = []
#         car_info = {}
#         cars_data = http.request.env['user.cars'].search([('id', '=', car_id)])
#         if cars_data:
#             for x in cars_data:
#                 car_info = {
#                     'car_brand': x.car_brand.id,
#                     'car_id': x.id,
#                     'car_model': x.car_model,
#                     'car_status': x.car_status,
#                     'name': x.name,
#                     'partner_id': x.partner_id.id,
#                     'partner_mobile': x.partner_mobile,
#                     'car_reading_per_day': x.car_reading_per_day,
#                     'current_reading': x.current_reading,
#                     'vehicle_no': x.vehicle_no,
#                     'km_for_next_service': x.km_for_next_service,
#                     'car_reading_ids': x.car_reading_ids.ids,
#                 }
#                 cars.append(car_info)
#         print('returning array of cars', cars)
#         jsonStr = json.dumps(cars)
#         return jsonStr
#
#     @http.route('/api/car_brands', auth='user')  # car_brands api
#     def car_brands_fetch(self):
#         print("acquiring car_brands for your pos")
#         car_brands = []
#         brand_info = {}
#         brands_data = http.request.env['user.cars.brands'].search([])
#         if brands_data:
#             for x in brands_data:
#                 brand_info = {
#                     'id': x.id,
#                     'car_brand': x.car_brand,
#
#                 }
#                 car_brands.append(brand_info)
#         print('returning array of car brands', car_brands)
#         jsonStr = json.dumps(car_brands)
#         return jsonStr
#
#     @http.route('/api/car_brand/<brand_id>', auth='user')  # car_brand api
#     def car_brand_fetch(self, brand_id):
#         print("acquiring car_brand for your pos")
#         car_brands = []
#         brand_info = {}
#         brands_data = http.request.env['user.cars.brands'].search([('id', '=', brand_id)])
#         if brands_data:
#             for x in brands_data:
#                 brand_info = {
#                     'id': x.id,
#                     'car_brand': x.car_brand,
#
#                 }
#                 car_brands.append(brand_info)
#         print('returning car brand', car_brands)
#         jsonStr = json.dumps(car_brands)
#         return jsonStr
#
#     @http.route('/api/car_reading_details/<car_reading_id>', auth='user')  # car's reading api
#     def reading_fetch(self, car_reading_id):
#         print("acquiring car reading for your pos")
#         car_reading_info = {}
#         car_reading_data = http.request.env['user.cars.readings'].search([('id', '=', car_reading_id)])
#         if car_reading_data:
#             date_next_service = car_reading_data.date_of_next_service.strftime("%m/%d/%Y")
#             car_reading_info = {
#                 'car_id': car_reading_data.car_id.id,
#                 'pos_order_id': car_reading_data.pos_order_id.id,
#                 'car_reading_per_day': car_reading_data.car_reading_per_day,
#                 'current_reading': car_reading_data.current_reading,
#                 'reading_on_next_service': car_reading_data.reading_on_next_service,
#                 'date_of_next_service': date_next_service,
#
#             }
#         print('returning car reading info ', car_reading_info)
#         jsonStr = json.dumps(car_reading_info)
#         return jsonStr
#
#     @http.route('/api/customers_oil', auth='user')  # partner api for ramp POS
#     def customer_oil_fetch(self, ):
#         print("acquiring customers for your pos")
#         partners = []
#         customer_info = {}
#         car_info = {}
#         cars = []
#         cust_data = http.request.env['res.partner'].search([('customer', '=', True)])
#         if cust_data:
#             for x in cust_data:
#                 if x.image_1920:
#                     image_base = x.image_1920
#                     image_final = "data:image/jpeg;base64," + image_base.decode()
#                 else:
#                     image_final = False
#                 customer_info = {'address': x.contact_address or False,
#                                  'barcode': x.barcode or False,
#                                  'id': x.id or False,
#                                  'city': x.city or False,
#                                  'cars_id': x.cars_id.ids or False,
#                                  'country_id': [x.country_id.id, x.country_id.name] or False,
#                                  'email': x.email or False,
#                                  'name': x.name or False,
#                                  'phone': x.phone or False,
#                                  'image': image_final,
#                                  'property_account_position_id': [x.property_account_position_id.id,
#                                                                   x.property_account_position_id.display_name] or False,
#                                  'property_product_pricelist': [x.property_product_pricelist.id,
#                                                                 x.property_product_pricelist.display_name] or False,
#                                  'state_id': [x.state_id.id, x.state_id.display_name] or False,
#                                  'street': x.street or False,
#                                  'vat': x.vat or False,
#                                  'write_date': x.write_date.strftime('%Y-%m-%d %H:%M:%S') or False,
#                                  'zip': x.zip or False,
#                                  }
#                 partners.append(customer_info)
#         print('returning array of customers', partners)
#         jsonStr = json.dumps(partners)
#         return jsonStr
#
# # class Home(http.Controller):
# #     @http.route('/web/login', type='http', auth="none")
# #     def web_login(self, redirect=None, **kw):
# #         print("123")
# #         if main.ensure_db():
# #             main.ensure_db()
# #             request.params['login_success'] = False
# #             if request.httprequest.method == 'GET' and redirect and request.session.uid:
# #                 return http.redirect_with_hash(redirect)
# #
# #             if not request.uid:
# #                 request.uid = odoo.SUPERUSER_ID
# #
# #             values = request.params.copy()
# #             try:
# #                 values['databases'] = http.db_list()
# #             except odoo.exceptions.AccessDenied:
# #                 values['databases'] = None
# #
# #             if request.httprequest.method == 'POST':
# #                 old_uid = request.uid
# #                 try:
# #                     uid = request.session.authenticate(request.session.db, request.params['login'],
# #                                                        request.params['password'])
# #                     request.params['login_success'] = True
# #                     return http.redirect_with_hash(self._login_redirect(uid, redirect=redirect))
# #                 except odoo.exceptions.AccessDenied as e:
# #                     request.uid = old_uid
# #                     if e.args == odoo.exceptions.AccessDenied().args:
# #                         values['error'] = _("Wrong login/password")
# #                     else:
# #                         values['error'] = e.args[0]
# #             else:
# #                 if 'error' in request.params and request.params.get('error') == 'access':
# #                     values['error'] = _('Only employee can access this database. Please contact the administrator.')
# #
# #             if 'login' not in values and request.session.get('auth_login'):
# #                 values['login'] = request.session.get('auth_login')
# #
# #             if not odoo.tools.config['list_db']:
# #                 values['disable_database_manager'] = True
# #
# #             response = request.render('web.login', values)
# #             response.headers['X-Frame-Options'] = 'DENY'
# #             return response
# #         else:
# #             return werkzeug.utils.redirect('/api/login_verification')
