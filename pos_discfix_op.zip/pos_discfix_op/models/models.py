# -*- coding: utf-8 -*-

from odoo import models, fields, api


class pos_discfix_op(models.Model):
    _inherit = 'pos.config'
    _description = 'check/uncheck option for disc_fix button'

    check_disc_fix = fields.Boolean(string='Enable or Disable fixed discount', default=False)
