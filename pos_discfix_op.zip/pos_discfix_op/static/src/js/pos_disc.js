odoo.define('pos_discfix.pos_disc', function(require) {
    "use strict";

    var gui = require('point_of_sale.gui');
    var core = require('web.core');
    var screens = require('point_of_sale.screens');
    var models = require('point_of_sale.models');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var DiscountBase = require('pos_discount.pos_discount');
    var PinPopupWidget =require('pos_tax_free_order.models');
    var Model = require('web.rpc');
    var field_utils = require('web.field_utils');
    var DiscountButtonWidget = DiscountBase.DiscountButton;
    var round_pr = require('web.utils').round_precision;
    var _t = require('web.core')._t;
    var entered =false;


   models.load_fields('pos.config',['ask_password_order_discount']);


   DiscountBase.DiscountButton.include({
     button_click: function(){
        var self = this;
        this._super();
        if(self.pos.config.ask_password_order_discount){
            self.gui.show_popup('POS_tax_free_password', {
                'parameter': 'discount_button',
                'confirm': function(value) { },
            });
        }
     },
     });
});