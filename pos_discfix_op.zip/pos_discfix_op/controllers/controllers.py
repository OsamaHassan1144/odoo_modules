# -*- coding: utf-8 -*-
# from odoo import http


# class PosDiscfixOp(http.Controller):
#     @http.route('/pos_discfix_op/pos_discfix_op/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pos_discfix_op/pos_discfix_op/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('pos_discfix_op.listing', {
#             'root': '/pos_discfix_op/pos_discfix_op',
#             'objects': http.request.env['pos_discfix_op.pos_discfix_op'].search([]),
#         })

#     @http.route('/pos_discfix_op/pos_discfix_op/objects/<model("pos_discfix_op.pos_discfix_op"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pos_discfix_op.object', {
#             'object': obj
#         })
