odoo.define('visio_pos_hotkeys.pos_hotkeys', function (require) {
    "use strict";

    var screens = require('point_of_sale.screens');
    var PopupWidget = require('point_of_sale.popups');
    var core = require('web.core');
    var gui = require('point_of_sale.gui');

    /* customizing product screen widget for shortcut */
    var ShortcutTipsWidget = PopupWidget.extend({
        template: 'ShortcutTipsWidget',
        show: function () {
            this._super();
        }
    });
    gui.define_popup({name: 'shortcuttips', widget: ShortcutTipsWidget});


    var ProductScreenWidget = screens.ProductScreenWidget.include({
        init: function(parent, options){
            this._super(parent,options);

            var self = this;

            var key_checker;
            var selectedRow;
            var previousRow;
            var currentRow;
            var enter_p_allow=false;
            var clientcarscreen =false;
            var pincodescreen =false;
            var enter_allow =false;
            var esc_p_allow =false;

            this.product_screen_keydown_event_handler = function(event){
            if(!$($(document).find(".product-screen")[0]).hasClass('oe_hidden')){

                    if(event.which == 113  && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ) {      // click on " F2 " button
                        console.log("tips");
                         esc_p_allow =true;

                        $(document).find("#shortcut_tips_btn").trigger("click");
                    }
                    if((event.altKey && event.which == 67) && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ) {      // click on " alt + c " button
                        console.log("customer");
                        event.preventDefault();
                        selectedRow = 0;
                        previousRow = 0;
                        key_checker = 0;
                        enter_allow = false;
                        $(document).find(".set-customer").trigger("click");
                         if (!$(document).find("div.clientlist-screen span.searchbox input").is(":focus"))
                        {
                            $(document).find("div.clientlist-screen span.searchbox input").focus();
                        }
                    }
                    if((event.altKey && event.which == 80) && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " alt + p " button
                        console.log("products");
                        event.preventDefault();
                        $(document).find("div.product-screen div.rightpane div.searchbox input").focus();
                    }
                    if(event.which == 13 && $(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " enter after alt+p" button
                        console.log(" first products");
                        event.preventDefault();
                        var curElement = $($(document).find("div.product-list article.product").first()).focus();
                        var curElements = $($(document).find("div.product-list article.product")).is(':focus');
                        var currentElement = $($(document).find("div.product-list article.product"))
                        console.log("info",currentElement,"help",curElements);
                        enter_p_allow=true;

                    }
                    if(event.which == 9 && $($(document).find("div.product-list article.product")[0]).is(':focus')  && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ){

                        console.log('working',$(document).find("div.product-list article.product").length)

                    }
                    if(event.which == 13 &&  $($(document).find("div.product-list article.product")).is(':focus') && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ){
                        event.preventDefault();
                        var $focused = $(':focus')
                        console.log('workings',$focused);
                        $focused .click();

                    }

                    if(event.which == 27 && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " enter after alt+p" button
                        console.log(" exit");
                        event.preventDefault();
                        $($(document).find("div.pos-rightheader div.header-button")[1]).click();

                    }
                    if((event.altKey && event.which == 107) && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " alt + "+" " button
                        console.log("new tab");
                        event.preventDefault();
                        $(document).find("span.order-button.square.neworder-button").trigger("click");
                    }
                    if((event.altKey && event.which == 109) && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " alt + '-' " button
                        console.log("last tab");
                        event.preventDefault();
                        var ordertabs = $(document).find("span.orders.touch-scrollable")[0].children
                        console.log("len",ordertabs.length);
                        for(var i = 1; i<= ordertabs.length; i++)
                        {
                            if($(ordertabs[i]).hasClass('selected'))
                            {
                                $(ordertabs[i + ((ordertabs.length - 1) - i)]).trigger('click');
                                console.log("yes");
                            }
                        }

                    }
                    if((event.altKey && event.which == 70) && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on " alt + f " button
                        console.log("final bill");
                        event.preventDefault();
                        $(document).find("button.button.pay").trigger("click");
                    }
                    if((event.altKey && event.which == 83) && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") && !$(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus")) {      // click on " alt + s " button
                        console.log("Cars");
                        event.preventDefault();
                        selectedRow = 0;
                        previousRow = 0;
                        key_checker = 0;
                        enter_allow = false;
                        clientcarscreen=true;
                        $(document).find(".default-partner-car").trigger("click");



                    }
                    if(event.which == 27 && $(document).find("div.product-screen div.rightpane div.searchbox input").is(":focus") && !$(document).find("div.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) {      // click on "esc" button when pressed 'p' button
                        console.log("esc products");
                        event.preventDefault();
                        $(document).find("div.product-screen div.rightpane div.searchbox input").blur();
                    }
                    if(event.altKey && event.which == 81){  // click on " alt + q" button
                        event.preventDefault();
                        self.numpad.state.changeMode('quantity');
                    }
                    if(event.altKey && event.which == 68){   // click on "alt + d" button
                         event.preventDefault();
                         console.log("discount mode numpad");
                         $(document).find("[data-mode='discount']").trigger("click");
                    }

                }
            if(!$($(document).find(".clientlist-screen")[0]).hasClass('oe_hidden')){
                    if((event.which == 27 && $(document).find("div.clientlist-screen span.searchbox input").is(":focus")) && $($(document).find(".modal-dialog")[17]).hasClass('oe_hidden') &&  $($(document).find(".modal-dialog")[20]).hasClass('oe_hidden') ) {            // click on "Esc" button
                            console.log("exit customer");
                            event.preventDefault();
                            $(document).find("span.back").trigger('click');
                    }
                    if((event.which == 38 && $(document).find("div.clientlist-screen span.searchbox input").is(":focus") && !$(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) && $($(document).find(".modal-dialog")[17]).hasClass('oe_hidden'))  {      // click on "Arrow Up" button  to navigate customer
                         console.log("up customer");
                         event.preventDefault();
                        if($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").length > 0){
                            $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").prev("tr.client-line").click();
                        }else{
                            var clientLineLength = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line").length;
                            if(clientLineLength > 0){
                                $($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line")[clientLineLength-1]).click();
                            }
                        }
                    }
                    if((event.which == 40 && $(document).find("div.clientlist-screen span.searchbox input").is(":focus") && !$(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) && $($(document).find(".modal-dialog")[17]).hasClass('oe_hidden') ) {      // click on "Arrow Down" button to navigate customer
                        console.log("down customer");
                        if($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").length > 0){
                            $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.highlight").next("tr.client-line").click();
                        }else{
                            var clientLineLength = $(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line").length;
                            if(clientLineLength > 0){
                                $($(document).find("div.clientlist-screen table.client-list tbody.client-list-contents tr.client-line")[0]).click();
                            }
                        }
                    }
                    if(( event.which == 13 && $(document).find("div.clientlist-screen span.searchbox input").is(":focus") && !$(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus")) && $($(document).find(".modal-dialog")[17]).hasClass('oe_hidden')) {      // click on "Enter" button
                        event.preventDefault();

                        if(!$(document).find("div.clientlist-screen section.top-content span.next").hasClass('oe_hidden')){
                            console.log("selected customer", clientcarscreen);
                            $(document).find("div.clientlist-screen section.top-content span.next").click();
                        }
                    }
                 }
            if(!$($(document).find(".modal-dialog")[17]).hasClass('oe_hidden')){
                    if(event.which == 40 && $(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ) {      // click on " down " button
                        event.preventDefault();
                        console.log("down");
                            console.log("rows",rows,"",);
                            console.log('key_checker',key_checker);
                            key_checker = key_checker + 1;
                            var rows = $(".client-cars-list")[1].childNodes[3].childNodes;
                            if(key_checker <= rows.length &&  key_checker >= 0 ){
                                if(selectedRow > previousRow && selectedRow != previousRow ){ // equal when on same row & greater means its on next row
                                     //remove previous row color
                                     console.log("remove color down");
                                     rows[previousRow].style.backgroundColor = "";
                                }
                                rows[selectedRow].style.backgroundColor = "rgb(152,251,152)";
                                console.log("okay working",selectedRow,rows[selectedRow]);
                                console.log("key", key_checker);
                                previousRow = selectedRow;
                                selectedRow++;
                            }
                            else{
                                console.log("ended list");
                            }
                            enter_allow = true;
                    }
                    if(event.which == 38 && $(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ) {      // click on " up " button
                       event.preventDefault();
                       console.log("up");
                            console.log('key_checker',key_checker);
                            console.log('previous_row',previousRow);
                            console.log('selectedRow',selectedRow);
                            selectedRow = previousRow;
                            if(selectedRow > 0 )
                            {
                                  previousRow = previousRow - 1 ;
                            }
                            var rows = $(".client-cars-list")[1].childNodes[3].childNodes;
                            console.log("rows",rows);
                            if(key_checker < = rows.length && key_checker > = 0  )
                            {
                                if( selectedRow > previousRow && selectedRow != previousRow  ) // equal when on same row & greater means its on next row
                                {
                                     //remove previous row color
                                     console.log("remove color up");
                                     rows[selectedRow].style.backgroundColor = "";
                                }
                                rows[previousRow].style.backgroundColor = "rgb(152,251,152)";
                                console.log("okay working",previousRow,rows[previousRow]);
                                console.log("key", key_checker);
                            }
                            else
                            {
                                console.log("ended list");
                            }
                            enter_allow = true;

                    }
                    if(event.which == 13 && $(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") && enter_allow) {      // click on " up " button
                        event.preventDefault();
                        console.log("enter",clientcarscreen);
                           console.log('previous_row',previousRow);
                           console.log('selectedRow',selectedRow);
                           var rows = $(".client-cars-list")[1].childNodes[3].childNodes;
                           if(selectedRow < = 0)
                           {
                             selectedRow = 0;
                           }
                           if(selectedRow > 0 && selectedRow <=  rows.length )
                           {
                               selectedRow =   selectedRow - 1 ;
                           }
                           console.log("rows",rows[selectedRow]);
                           enter_allow =false;
                           $(rows[selectedRow]).find("td .set-default-car").trigger("click");
                           console.log("do i run");
                    }
                    if(event.which == 27 && $(document).find("div.popup.car-select-default.car-list-creation div.body div.search-default-cars input.input-search-car").is(":focus") ) {      // click on " esc " button
                       event.preventDefault();
                        console.log("exit car screen");
                            clientcarscreen =false;
                            $(document).find(".footer div.button.cancel").trigger('click');


                     }

              }
            if(!$($(document).find(".modal-dialog")[20]).hasClass('oe_hidden')){
               console.log("this is pin");
                if(event.which == 27 && $(document).find("div.popup div.body div.tax-free-input input.text-free-input-class.customer-oil-change").is(":focus") ) {
                       event.preventDefault();
                        console.log("exit pin screen");
                        $($(document).find("div.popup div.footer div.button.cancel")[1]).trigger('click');

                     }
                 if(event.which == 13 && $(document).find("div.popup div.body div.tax-free-input input.text-free-input-class.customer-oil-change").is(":focus") ) {
                       event.preventDefault();
                        console.log("ok pin screen");
                        $($(document).find("div.popup div.footer div.button.done-select")[1]).trigger('click');
                     }
            }
            if(!$($(document).find(".modal-dialog-shortcut-tips")[0]).hasClass('oe_hidden')){
                console.log('hello shortcut popup');
                if(event.which == 27 &&  esc_p_allow)

                {
                     event.preventDefault();
                     $(document).find("footer.footer div.button.cancel").trigger('click');
                     esc_p_allow =false;
                }

            }
            }
         $(document).find("body").on('keydown', this.product_screen_keydown_event_handler);
        },
        show: function () {
            this._super();
            var self = this;
            $("#shortcut_tips_btn").on("click", function (event) {

                self.gui.show_popup("shortcuttips");
            });
        }
    });



});