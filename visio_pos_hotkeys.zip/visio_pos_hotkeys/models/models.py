# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class visio_pos_hotkeys(models.Model):
#     _name = 'visio_pos_hotkeys.visio_pos_hotkeys'
#     _description = 'visio_pos_hotkeys.visio_pos_hotkeys'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
