# -*- coding: utf-8 -*-
# from odoo import http


# class VisioPosHotkeys(http.Controller):
#     @http.route('/visio_pos_hotkeys/visio_pos_hotkeys/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/visio_pos_hotkeys/visio_pos_hotkeys/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('visio_pos_hotkeys.listing', {
#             'root': '/visio_pos_hotkeys/visio_pos_hotkeys',
#             'objects': http.request.env['visio_pos_hotkeys.visio_pos_hotkeys'].search([]),
#         })

#     @http.route('/visio_pos_hotkeys/visio_pos_hotkeys/objects/<model("visio_pos_hotkeys.visio_pos_hotkeys"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('visio_pos_hotkeys.object', {
#             'object': obj
#         })
