# -*- coding: utf-8 -*-

from odoo import api, fields, models, http


class POSOrderQueue(models.Model):
    _name = 'pos.queue'

    s_name = fields.Char(string="Session Name", store=True)
    s_id = fields.Integer(string="Session Number", store=True)
    s_login_number = fields.Integer(string="Session Login Number", store=True)
    token_number = fields.Char(string="Token Number", store=True)
    table_name = fields.Char(string="Table Name", store=True)
    order_type = fields.Selection([('dine_in', 'Dine In'),
                                   ('delivery', 'Delivery'),
                                   ('takeaway', 'Take Away')], string="Order Type", default='dine_in', store=True)
    partner_id = fields.Char(store=True)
    pos_order_id = fields.Char(store=True)
    est_time = fields.Text(string="estimated time", store=True)
    order_progress = fields.Selection([('in_queue', 'In Queue'),
                                       ('delivered', 'Delivered'),
                                       ('in_progress', 'In Progress'), ('served', 'Served'),
                                       ('done', 'Done')], string="Order progress", default='in_queue', store=True)
    no_items = fields.Integer(string='No of Items', store=True)
    queue_line_ids = fields.One2many('pos.queue.line', 'queue_id')

    @api.model
    def create_token(self, val_list):
        res = super(POSOrderQueue, self).create(val_list)
        # print("yes working")
        return res.id

    @api.model
    def check_token_status(self, hello):
        res = http.request.env['pos.queue'].search([('token_number', '=', hello)])
        return res.order_progress

    @api.model
    def check_queue_id(self, hellos):
        res = http.request.env['pos.queue'].search([('token_number', '=', hellos)])
        return res.id


class POSOrderQueueLine(models.Model):
    _name = 'pos.queue.line'

    queue_id = fields.Many2one('pos.queue')
    product_name = fields.Char(store=True)
    product_category = fields.Char(store=True)
    product_quantity = fields.Integer(store=True)

    @api.model
    def create_queue_order(self, val_list):
        que = self.env['pos.queue'].search([('id', '=', val_list['queue_id'])])
        if que:
            val_list['queue_id'] = ""
        res = super(POSOrderQueueLine, self).create(val_list)
        res.queue_id = que
        return res

    @api.model
    def update_queue_order(self, new_product_list):
        que = self.env['pos.queue'].search([('id', '=', new_product_list['queue_id'])])
        pue = self.env['pos.queue.line'].search(
            [('queue_id', '=', new_product_list['queue_id']), ('product_name', '=', new_product_list['product_name'])])
        if pue:
            pue.product_quantity += 1
        else:
            new_product_list['queue_id'] = ""
            res = super(POSOrderQueueLine, self).create(new_product_list)
            res.product_quantity = 1
            res.queue_id = que
            return res


class token_update(models.Model):
    _name = 'pos.sequence'

    token_sequence = fields.Char(string="Token Sequence Saver", store=True, default="0001")
    session_id = fields.Many2one('pos.config', store=True)

    @api.model
    def current_data(self, my_data):
        session_id = my_data['session_id']
        my_sequence = self.env['pos.sequence'].search([('session_id', '=', session_id)])
        if my_sequence:
            convert_int_token = int(my_sequence.token_sequence)
            convert_int_token = convert_int_token + 1
            convert_str_token = str(convert_int_token)
            my_sequence.token_sequence = convert_str_token
            if len(convert_str_token) == 1:
                my_sequence.token_sequence = "000" + convert_str_token
            elif len(convert_str_token) == 2:
                my_sequence.token_sequence = "00" + convert_str_token
            elif len(convert_str_token) == 3:
                my_sequence.token_sequence = "0" + convert_str_token
            else:
                my_sequence.token_sequence = convert_str_token

    @api.model
    def update_seq(self, shop_id):
        cont_sequence = self.env['pos.sequence'].search([('session_id', '=', shop_id)])
        return cont_sequence.token_sequence

    @api.model
    def reset_seq(self):
        cont_sequence = self.env['pos.sequence'].search([])
        cont_sequence.token_sequence = "0001"
        for records in self.env['pos.queue'].search([]):
            records.unlink()


class pos_seq(models.Model):
    _inherit = 'pos.config'

    time_feat = fields.Boolean(default=False, string="Estimate Time Option")
    order_queue_feat = fields.Boolean(default=False, string="In-POS queue screen  Option")
    order_type_feat = fields.Boolean(default=False, string="Order Type Option")

    def intialize_sequence(self):
        val_list = {'session_id': self.id}
        res = self.env['pos.sequence'].search([('session_id', '=', self.id)])
        if not res:
            self.env['pos.sequence'].create(val_list)

    @api.model
    def create(self, values):
        res = super(pos_seq, self).create(values)
        val_list = {'session_id': res.id}
        self.env['pos.sequence'].create(val_list)
        return res
