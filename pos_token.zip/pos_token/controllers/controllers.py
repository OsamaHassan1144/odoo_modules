# -*- coding: utf-8 -*-
from odoo import http


class PosToken(http.Controller):
    @http.route('/<s_name>/orderqueuelist/', auth='user')
    def token_scr(self, s_name):
        print("123we32")
        data = http.request.env['pos.queue'].search(
            [('order_progress', 'in', ('in_queue', 'in_progress', 'done')), ('s_name', '=', s_name)])
        return http.request.render('pos_token.order_details_page', {
            'object': data
        })

    @http.route('/<s_name>/kitchensidescreen/', auth='user')
    def kitchen_side_token_scr(self, s_name):
        print("456ew65")
        data = http.request.env['pos.queue'].search(
            [('order_progress', 'in', ('in_queue', 'in_progress')), ('s_name', '=', s_name)])
        res = http.request.render('pos_token.order_kitchenside_page', {
            'objects': data
        })
        return res

    @http.route('/pos_token/token_isdone', auth='user')
    def update_kitchen_done(self, **kw):
        print("4321")
        tok = kw['token_num']
        res = http.request.env['pos.queue'].search([('token_number', '=', tok)])
        res.order_progress = 'done'

    @http.route('/pos_token/token_progress', auth='user')
    def update_kitchen_in_progress(self, **kw):
        print("1234")
        tok = kw['token_num']
        res = http.request.env['pos.queue'].search([('token_number', '=', tok)])
        res.order_progress = 'in_progress'

    @http.route('/pos_token/token_served', auth='user')
    def update_order_served(self, **kw):
        print("78910")
        tok = kw['token_num']
        res = http.request.env['pos.queue'].search([('token_number', '=', tok)])
        res.order_progress = 'served'

    @http.route('/pos_token/token_delivered', auth='user')
    def update_order_delivered(self, **kw):
        print("011012013")
        tok = kw['token_num']
        res = http.request.env['pos.queue'].search([('token_number', '=', tok)])
        res.order_progress = 'delivered'
