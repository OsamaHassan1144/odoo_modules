# -*- coding: utf-8 -*-
{
    'name': "POS Kitchen module",

    'summary': """
        Kitchen management module  """,

    'description': """
        Kitchen based POS Module/ restaurant system v1.0 (beta) with :
            1. Token system - generate a unique token number for current order.  
            2. Print - feature allow you to print a token from POS interface in simple and easy to read template.
            3. Estimated time feature - allow you to add estimate time to each order [ will add countdown timer in near future].
            4. separate order queue screen [with built in POS interface order queue screen feature] and kitchen side screen.
            5. Managing order into four states i.e.
                a. In Queue.
                b. In Progress.
                c. Done.
                d. Served.
        UPDATES
        
        [16-Mar-2021]
                * Added Order Type feature [optional feature, can be disable from config].
                * Order Served button added.
                * UI design of Kitchen Screen and Order Queue Screen improved and made more user friendly.
                * Easy Error Handling and made more easier for novice user to use with user friendly language and interactive responses.
                * Specific Token sequence added.(before tht token were randomly generated)
                * Compatible with table management of POS RESTAURANT.
        [22-jan-2021]
                * Module Working version (beta) was installed and running.  
    """,

    'author': "Osama Hassan @Visiomate",
    'website': "https://visiomate.com/about.html",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'point_of_sale', 'web', ],

    'css': [''],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/kitchenviews.xml',
        'views/Qrderqueue.xml',
        'views/templates.xml',
        'demo/demo.xml',
    ],

    # only loaded in demonstration mode
    'demo': [

    ],

    'qweb': ['static/src/xml/pos_inherit.xml', 'static/src/xml/ticket_report.xml', ],
}
