
// ------------ not active -----------
odoo.define('pos_token.pos_orderqueue', function (require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require ('web.Widget');
    var ajax = require ('web.ajax');
    var rpc = require('web.rpc');


    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');
    var field_utils = require('web.field_utils');
    var _super_order_model = PosModel.Order.prototype;

    var QWeb = core.qweb;
    var _t = core._t;



var OrderQueueScreenWidget = screens.ScreenWidget.extend({
    template: 'OrderQueueScreenWidget',

    init: function(parent, options){
        this._super(parent, options);

    },

    auto_back: true,

    show: function(){
        var self = this;
        this._super();

        this.renderElement();
        var datas=this.pos.get_order_list();
        this.render_list(datas);



        this.$('.back').click(function(){
            self.gui.back();
        });
    },

    render_list: function(datas){
        var contents = this.$el[0].querySelector('.orderqueue-list-contents');
        contents.innerHTML = "";
        for(var i = 0, len = Math.min(datas.length,1000); i < len; i++){
            var order   = datas[i];
            var order_line_html = QWeb.render('PosOrderQueueLine',{widget: this, order:order});
            var order_line = document.createElement('tbody');
            order_line.innerHTML = order_line_html;
            order_line = order_line.childNodes[1];
            contents.appendChild(order_line);
        }
        },

});
gui.define_screen({ name:'orderqueue', widget: OrderQueueScreenWidget, });

var OrderQueueButton = screens.ActionButtonWidget.extend({
    template: 'orderqueue_button',
     button_click: function(){

        var self = this;


        self.orderqueue_function();

    },

    orderqueue_function: function(){

        var e_time = $(".time_estimate_order option:selected").val();
        this.gui.show_screen('orderqueue');

    }

});
    screens.define_action_button({ 'name': 'orderqueue_button',
        'widget': OrderQueueButton,
           'condition': function(){
                    return this.pos.config.order_queue_feat;
                    }
});
});