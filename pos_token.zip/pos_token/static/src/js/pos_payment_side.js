odoo.define('pos_token.DisplayButton', function (require) {
    "use strict";

    var ajax = require('web.ajax');

    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require ('web.Widget');
    var ajax = require ('web.ajax');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PaymentScreenWidget = screens.PaymentScreenWidget;
    var ChromeHeaderWidget=chrome.HeaderButtonWidget;
    var _t = core._t;


  PaymentScreenWidget.include({
    init: function(parent, options) {
        var self = this;
        this._super(parent, options);
    },
    click_token_value: function(){
    var tkn= this.pos.get_order().token_number;
    console.log ("value of token :"  + tkn );
    },
    renderElement: function() {
        var self = this;
        this._super();
        this.$('.js_token_value').click(function(){
            self.click_token_value();
        });
    }


});
  PaymentScreenWidget.include({
     validate_order: function(force_validation) {
        var order = this.pos.get_order();
//        console.log("hello my brother");

//        this.gui.show_popup('confirm', {
//                            'title': _t('Are you sure  ?'),
//                            'body': _t('Order is ReadyReady ! Do you want serve the order   ?'),
//                            confirm: function() {
//
//
//                            },
//                             cancel: function()
//                            {
//                            },
//                        });
        if (this.order_is_valid(force_validation)) {
//        console.log("hello my friend");

            if(order.order_type!="delivery")
            {
                let input_data = {
                    token_num : order.token_number,
                }
                console.log(input_data);
                 var options = {
                    url: '/pos_token/token_served',
                    data: input_data,
                    dataType: 'JSON',
                    success: function(data) {
                        if (typeof(data) == 'string') {
                            console.log(data);
                        }

                    },
                    error: function(a) {
                        console.log(a.responseText);
                    }
                }
                $.ajax(options);
                console.log("after validation:",order);
                this.finalize_validation();

            }
            else
            {
                let input_data = {
                    token_num : order.token_number,
                }
//                console.log(input_data);
                 var options = {
                    url: '/pos_token/token_delivered',
                    data: input_data,
                    dataType: 'JSON',
                    success: function(data) {
                        if (typeof(data) == 'string') {
                            console.log(data);
                        }

                    },
                    error: function(a) {
                        console.log(a.responseText);
                    }
                }
                $.ajax(options);
                let order_data = localStorage.getItem('order_value -'+ order.uid);
                console.log(order.uid);
                if(order_data)
                 {
                   localStorage.removeItem('order_value -'+order.uid);
                 }
                console.log("after validation:",order);
                this.finalize_validation();
                console.log("after validation:",order);


            }
        }
    },

   });

});
