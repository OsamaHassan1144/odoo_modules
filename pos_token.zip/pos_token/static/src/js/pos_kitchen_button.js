
 $(function(){

            var token_don;
            var token_pro;

            $(".button_submitt").click(function(){
              token_don = $(this).parent().find("#token_num").val();
              var input_data = {
                token_num: token_don,
            };
            var options = {
                url: '/pos_token/token_isdone',
                data: input_data ,
                dataType:'JSON',
                success: function(data){
                    if(typeof(data) == 'string')
                    {
                    }
                },
                error:function(a){
                }

            };
            $.ajax(options);
            location.reload();
            });
            $(".button_progress").click(function(){
              token_pro = $(this).parent().find("#token_num").val();
              var input_data = {
                token_num: token_pro,
                };
            var option = {
                url: '/pos_token/token_progress',
                data: input_data ,
                dataType:'JSON',
                success: function(data){
                    if(typeof(data) == 'string')
                    {
                    }
                },
                error:function(a){
                }
            };
            $.ajax(option);
            location.reload();
            });

       }
 );
