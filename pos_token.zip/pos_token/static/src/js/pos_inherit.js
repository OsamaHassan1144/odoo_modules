odoo.define('pos_token.pos_inherit', function(require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');
    var field_utils = require('web.field_utils');
    var _super_order_model = PosModel.Order.prototype;
    var ProductListWidgets = screens.ProductListWidget;
    var OrderSelectorWidgets = chrome.OrderSelectorWidget;

//---------------- Variables Declaration -----------------
    var CurrentOrder;
    var PreviousOrder;
    var c_time;
    var current_table_name;
    var torder;
    var pos_info;
    var customer_name;
    var shop_name;
    var shop_session_login_number;
    var shop_session_id;
    var queue_lines = [];
    var current_queue_id;
    var val_list;
    var line;
    var Token;
    var current_order_token;
    var length_orderline;
    var e_time;
    var pos_table;
    var Progress;
    var order_type;
    var products;
    var R_receipt;
    var idee;
    var our_data;
    var current_order;
    var fetch_status="";


    var QWeb = core.qweb;
    var _t = core._t;

chrome.OrderSelectorWidget.include({
    floor_button_click_handler: function(){
        this.pos.set_table(null);
    },
    renderElement: function(){
        var self = this;
        this._super();
       if (this.pos.config.iface_floorplan) {
                if (this.pos.get_order()) {
                    if (this.pos.table && this.pos.table.floor)
                    {
                        var pos_order = this.pos.get_order();
                        let order_data = localStorage.getItem('order_value -'+ pos_order.uid);
                        if(order_data)
                        {
                            var stringify = JSON.parse(order_data);
                            pos_order.token_number = stringify['token_number'];
                            pos_order.order_progress = stringify['order_progress'];
                            pos_order.est_time = stringify['est_time'];
                            pos_order.order_type = stringify['order_type'];

                        }
                    }
                }
       }


    },
});




//---------------- Generate Token Button -----------------
    var TokenButton = screens.ActionButtonWidget.extend({
        template: 'token_button',
        button_click: function() {
            var self = this;
            torder = self.pos.get_order();
            pos_table = self.pos.table;
            console.log('torder =>',torder);

            pos_info=self.pos.pos_session;

            if(this.pos.get_client())
            {
                customer_name=this.pos.get_client().name;
            }
            else
            {
                customer_name=torder.cid;
            }
            if(this.pos.get_order().table)
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                current_table_name = torder.table.name;
                CurrentOrder = customer_name;
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                e_time = torder.est_time;
                fetch_status="queue";
                shop_name = torder.pos.config.name;
                  rpc.query({
                            model: 'pos.sequence',
                            method: 'update_seq',
                            args: [shop_session_id],
                            }).then(function(token_sequence) {
                                self.token_function(token_sequence);
                            }).catch(function(reason) {
                                var error = reason.message;
                                console.log(error);
                        });
           }
           else
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                CurrentOrder = customer_name;
                current_table_name="";
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                e_time = torder.est_time;
                fetch_status="queue";
                shop_name = torder.pos.config.name;
                  rpc.query({
                            model: 'pos.sequence',
                            method: 'update_seq',
                            args: [shop_session_id],
                            }).then(function(token_sequence) {
                                self.token_function(token_sequence);
                            }).catch(function(reason) {
                                var error = reason.message;
                                console.log(error);
                        });
           }
        },
        token_function: function(tokens) {

             pos_table = this.pos.table;
             console.log('pos_table in token function =>',pos_table);

                if (!torder.token_number) {

                    if(length_orderline >=1 )
                    {

                        torder.token_number=tokens;
                        Token =torder.token_number;
                        our_data = {
                            'token_number':Token,
                            'session_id':shop_session_id,
                        };
                        rpc.query({
                            model: 'pos.sequence',
                            method: 'current_data',
                            args: [our_data],
                        }).then(function(token_sequence) {
                        }).catch(function(reason) {
                            var error = reason.message;
                            console.log(error);
                        });
                        e_time = $(".time_estimate_order option:selected").val();
                        order_type = $(".order_type option:selected").val();
                        if (e_time) {
                            Token = tokens;

                            torder.est_time = e_time;
                            torder.order_type = order_type;
                            torder.product_list = queue_lines;
                            torder.order_progress = "in_queue";
                            Swal.fire
                             ({
                                  icon: 'success',
                                  title: 'Token Generated ',
                                  showConfirmButton: false,
                                  timer: 5000,
                             });
                             PreviousOrder = CurrentOrder;
                             var m = torder.orderlines.models;

                        val_list = {
                            's_id':shop_session_id,
                            's_login_number':shop_session_login_number,
                            's_name':shop_name,
                            'table_name': current_table_name,
                            'token_number': Token,
                            'order_type': order_type,
                            'partner_id': customer_name,
                            'pos_order_id': torder.name,
                            'est_time': e_time,
                            'order_progress': torder.order_progress,
                        };
                         let order_data = localStorage.getItem('order_value -'+ torder.uid);
                         if(!order_data)
                         {
                           var str_data = JSON.stringify(val_list);
                           localStorage.setItem('order_value -' + torder.uid, str_data);
                         }

                        rpc.query({
                            model: 'pos.queue',
                            method: 'create_token',
                            args: [val_list],
                        }).then(function(res) {
                            idee = res;
                            for (var i = 0; i < m.length; i++) {
                                line = {
                                    'queue_id': idee,
                                    'product_name': m[i].product.display_name,
                                    'product_quantity': m[i].quantity,
                                    'product_category': m[i].product.pos_categ_id[1],
                                }
                                rpc.query({
                                    model: 'pos.queue.line',
                                    method: 'create_queue_order',
                                    args: [line],
                                }).then(function() {
                                    console.log("Success")
                                }).catch(function(reason) {
                                    var error = reason.message;
                                    console.log(error);
                                });
                            }
                        }).catch(function(reason) {
                            var error = reason.message;
                        });
                        }

                        else {

                            this.gui.show_popup('confirm',{
                                'title': _t('Are you sure  ?'),
                                'body': _t('Do you want to generate a token without selecting the "ESTIMATED TIME"  ?'),
                                confirm: function() {
                                    Token =tokens;
                                    torder.est_time = e_time;
                                    torder.order_type = order_type;
                                    torder.product_list = queue_lines;
                                    torder.order_progress = "in_queue";
                                    Swal.fire
                                     ({
                                          icon: 'success',
                                          title: 'Token Generated ',
                                          showConfirmButton: false,
                                          timer: 5000,
                                     });
                                    PreviousOrder = CurrentOrder;
                                    var m = torder.orderlines.models;
                                    val_list = {
                                        's_id':shop_session_id,
                                        's_login_number':shop_session_login_number,
                                        's_name':shop_name,
                                        'table_name': current_table_name,
                                        'token_number': Token,
                                        'order_type': order_type,
                                        'partner_id': customer_name,
                                        'pos_order_id': torder.name,
                                        'est_time': e_time,
                                        'order_progress': torder.order_progress,
                                    };
                                    rpc.query({
                                        model: 'pos.queue',
                                        method: 'create_token',
                                        args: [val_list],
                                    }).then(function(res) {
                                        idee = res;
                                        for (var i = 0; i < m.length; i++) {
                                            line = {
                                                'queue_id': idee,
                                                'product_name': m[i].product.display_name,
                                                'product_quantity': m[i].quantity,
                                                'product_category': m[i].product.pos_categ_id[1],
                                            }
                                            rpc.query({
                                                model: 'pos.queue.line',
                                                method: 'create_queue_order',
                                                args: [line],
                                            }).then(function() {
                                                console.log("Success")
                                            }).catch(function(reason) {
                                                var error = reason.message;
                                                console.log(error);
                                            });
                            }
                        }).catch(function(reason) {
                                        var error = reason.message;
                                    });
                                },
                                cancel: function() {
                                    console.log('cancel click');
                                },
                            });
                             }
                    }
                    else
                    {
                          Swal.fire({
                              icon: 'error',
                              title: 'You Cant Generate Token without items',
                              showConfirmButton: false,
                              timer: 10000
                          });
                    }

                }
                else
                {
                    Swal.fire
                    ({

                          icon: 'error',
                          title: 'Token Has already Generated',
                          showConfirmButton: false,
                          timer: 10000
                    });
                }
        },

    });
    screens.define_action_button({

        'name': 'token_button',
        'widget': TokenButton,

    });


//---------------- Order Type Dropdown -----------------
    var OrderTypeDropdownListWidget = screens.ActionButtonWidget.extend({
        template: 'order_type_dropdown',
        init: function() {
        },

    });
    screens.define_action_button({

        'name': 'order_type_dropdown',
        'widget': OrderTypeDropdownListWidget,
        'condition': function() {
            return this.pos.config.order_type_feat;
        }
    });

//---------------- Estimated Time Dropdown -----------------
    var TimeEstimateOrderDropdownListWidget = screens.ActionButtonWidget.extend({
        template: 'time_estimate_order_dropdown',
        init: function() {
        },

    });
    screens.define_action_button({

        'name': 'time_estimate_order_dropdown',
        'widget': TimeEstimateOrderDropdownListWidget,
        'condition': function() {
            return this.pos.config.time_feat;
        }

    });

//---------------- Order Served/Deliverd Button -----------------
    var ServeButton = screens.ActionButtonWidget.extend({
            template: 'serve_button',

            button_click: function() {
                var self = this;
                var order=this.pos.get_order();
                var opened_order = this.pos.get_order().my_token_number;
                console.log('opened_order 2 =>',opened_order);


                rpc.query({
                            model: 'pos.queue',
                            method: 'check_token_status',
                            args: [order.token_number],
                        }).then(function(stats) {
                            if(stats=="in_progress"){fetch_status="progress";}
                            if(stats=="in_queue"){fetch_status="queue";}
                            if(stats=="served"){fetch_status="served";}
                            if(stats=="delivered"){fetch_status="delivered";}
                            if(stats=="done"){fetch_status="done";}
                            if(stats==false){fetch_status="empty";}

                            self.serve_function(fetch_status);

                        }).catch(function(reason) {
                            var error = reason.message;
                            console.log(error);
                        });


            },
            serve_function: function(status) {
                var order=this.pos.get_order();
                console.log('order =>',order);
                 console.log("Token value",Token);

                if(status=="queue")
                {
                    if(order.order_type=="delivery")
                    {
                        this.gui.show_popup('confirm', {
                        'title': _t('Are you sure  ?'),
                        'body': _t('Do you want deliver the order as it is still " In Queue " status  ?'),
                        confirm: function() {
                             let input_data = {
                                token_num : order.token_number,
                             }
                             var options = {
                                url: '/pos_token/token_delivered',
                                data: input_data,
                                dataType: 'JSON',
                            }
                            status="delivered";
                            $.ajax(options);
                            order.order_progress="delivered";
                        },
                        cancel: function()
                            {
                            },

                    });
                   }
                   else
                   {
                        this.gui.show_popup('confirm', {
                        'title': _t('Are you sure  ?'),
                        'body': _t('Do you want serve the order as it is still " In Queue " status  ?'),
                        confirm: function() {
                             let input_data = {
                                token_num : order.token_number,
                             }
                             var options = {
                                url: '/pos_token/token_served',
                                data: input_data,
                                dataType: 'JSON',
                            }
                            status="served";
                            $.ajax(options);
                            order.order_progress="served";


                        },
                    });

                   }
                }
                if(status=="progress")
                {
                   if(order.order_type=="delivery")
                    {
                        this.gui.show_popup('confirm', {
                        'title': _t('Are you sure  ?'),
                        'body': _t('The Order is "In Progress", do you want to serve it'),
                        confirm: function() {
                             let input_data = {
                                token_num : order.token_number,
                             }
                             var options = {
                                url: '/pos_token/token_delivered',
                                data: input_data,
                                dataType: 'JSON',
                            }
                            status="delivered";
                            $.ajax(options);
                            order.order_progress="delivered";

                        },
                    });
                   }
                   else
                  {
                    this.gui.show_popup('confirm', {
                        'title': _t('Are you sure  ?'),
                        'body': _t('The Order is "In Progress", do you want to serve it'),
                        confirm: function() {
                             let input_data = {
                                token_num : order.token_number,
                             }
                             var options = {
                                url: '/pos_token/token_served',
                                data: input_data,
                                dataType: 'JSON',
                            }
                            status="served";
                            $.ajax(options);
                            order.order_progress="served";

                        },
                         cancel: function()
                            {
                            },
                        });
                  }
                }
                if(status=="done")
                {
                     if(order.order_type=="delivery")
                    {
                        this.gui.show_popup('confirm', {
                            'title': _t('Are you sure  ?'),
                            'body': _t('Order is Ready ! Do you want deliver the order   ?'),
                            confirm: function() {
                                 let input_data = {
                                    token_num : order.token_number,
                                 }
                                 var options = {
                                    url: '/pos_token/token_delivered',
                                    data: input_data,
                                    dataType: 'JSON',
                                }
                                status="delivered";
                                $.ajax(options);
                                order.order_progress="delivered";

                            },
                             cancel: function()
                            {
                            },
                        });
                    }
                    else
                    {
                        this.gui.show_popup('confirm', {
                            'title': _t('Are you sure  ?'),
                            'body': _t('Order is Ready ! Do you want serve the order   ?'),
                            confirm: function() {
                                 let input_data = {
                                    token_num : order.token_number,
                                 }
                                 var options = {
                                    url: '/pos_token/token_served',
                                    data: input_data,
                                    dataType: 'JSON',
                                }
                                status="served";
                                $.ajax(options);
                                order.order_progress="delivered";

                            },
                             cancel: function()
                            {
                            },
                        });
                    }
                }
                if(status=="served")
                {

                   Swal.fire
                   ({
                          icon: 'info',
                          title: 'Order Already served',
                          showConfirmButton: false,
                          timer: 10000
                   });
                }
                 if(status=="delivered")
                {
                   Swal.fire
                   ({
                          icon: 'info',
                          title: 'Order Already delivered',
                          showConfirmButton: false,
                          timer: 10000
                   });
                }
                if(status=="empty")
                {
                    if(order.orderlines.length >=1)
                    {
                        Swal.fire
                       ({
                              icon: 'info',
                              title: 'Token not Generated',
                              showConfirmButton: false,
                              timer: 8000
                       });
                    }
                    else
                    {
                         Swal.fire
                       ({
                              icon: 'info',
                              title: 'Nothing to serve',
                              showConfirmButton: false,
                              timer: 8000
                       });
                    }
                }
    },

});
    screens.define_action_button({
        'name': 'serve_button',
        'widget': ServeButton,
    });

//---------------- Print Token Button -----------------
    var PrintButton = screens.ActionButtonWidget.extend({
        template: 'print_button',
        button_click: function() {
            var self = this;
            self.print_function();
        },
        print_function: function() {
            var pos_od = this.pos.get_order();
            var our_token ;
            if(pos_od.token_number )
            {


                var Data = {
                    widget: self,
                    e_time: this.pos.get_order().est_time,
                    CurrentOrder: this.pos.get_order().name,
                    Token:  this.pos.get_order().token_number,
                    c_time: this.pos.get_order().creationtime,
                    order_type: this.pos.get_order().order_type,
                    token_orderlines: this.pos.get_order().orderlines.models,

                };
                R_receipt = QWeb.render('PosTicket2', Data);
                var printTicket = window.open('', '', 'height=400,width=800');
                printTicket.document.write(R_receipt);
                printTicket.document.close();
                 setTimeout(() => {  printTicket.print(); }, 1000);
            }
            else
            {
                  Swal.fire
                   ({
                          icon: 'info',
                          title: 'Generate a Token First',
                          showConfirmButton: false,
                          timer: 10000
                   });
            }
        }
    });
    screens.define_action_button({

        'name': 'print_button',
        'widget': PrintButton,
    });

//---------------- (+ button) new order button modifier -----------------
    OrderSelectorWidgets.include({
         neworder_click_handler: function(event, $el) {
            this.pos.add_new_order();
            Token=null;
         },
         deleteorder_click_handler: function(event, $el) {
            var self  = this;
            var order = this.pos.get_order();
            if (!order) {
                return;
            } else if ( !order.is_empty() ){
                this.gui.show_popup('confirm',{
                    'title': _t('Destroy Current Order ?'),
                    'body': _t('You will lose any data associated with the current order'),
                    confirm: function(){
                        self.pos.delete_current_order();
                          let order_data = localStorage.getItem('order_value -'+ order.uid);
                           console.log(order.uid);
                           if(order_data)
                           {
                               localStorage.removeItem('order_value -'+order.uid);
                           }
                    },
                });
            } else {
                this.pos.delete_current_order();
            }

    }
    });
//---------------- Product click modifier -----------------
    ProductListWidgets.include({
      init: function(parent, options) {
            var self = this;
            this._super(parent,options);
            this.click_product_handler = function(){
                var product = self.pos.db.get_product_by_id(this.dataset.productId);
                options.click_product_action(product);
                console.log("before adding",Token);
                var current_token=Token;
                var previous_token;
                var current_table=current_table_name;
                var previous_table;
                var current_order = torder;

                if(current_token)
                {
                    if(current_order.table)
                    {
                        if(current_token && current_table)
                        {
                           if(current_token!=previous_token && current_table != previous_table)
                            {
                                rpc.query({

                                    model: 'pos.queue',
                                    method: 'check_queue_id',
                                    args: [current_token],
                                }).then(function(q_id) {
                                 var new_product_list={
                                   'queue_id':q_id,
                                   'product_name':product.display_name,
                                   'product_category': product.pos_categ_id[1]
                                  }
                                     rpc.query({
                                        model: 'pos.queue.line',
                                        method: 'update_queue_order',
                                        args: [new_product_list],
                                    }).then(function() {

                                    }).catch(function(reason) {
                                        var error = reason.message;
                                        console.log(error);
                                    });



                                }).catch(function(reason) {
                                    var error = reason.message;
                                    console.log(error);
                                });

                            }
                             previous_token=current_token;
                             previous_table=current_table;

                        }
                    }
                    else
                    {
                        if(current_token)
                        {
                           if(current_token!=previous_token )
                            {
                                rpc.query({

                                    model: 'pos.queue',
                                    method: 'check_queue_id',
                                    args: [current_token],
                                }).then(function(q_id) {
                                 var new_product_list={
                                   'queue_id':q_id,
                                   'product_name':product.display_name,
                                   'product_category': product.pos_categ_id[1]
                                  }
                                     rpc.query({
                                        model: 'pos.queue.line',
                                        method: 'update_queue_order',
                                        args: [new_product_list],
                                    }).then(function() {

                                    }).catch(function(reason) {
                                        var error = reason.message;
                                        console.log(error);
                                    });



                                }).catch(function(reason) {
                                    var error = reason.message;
                                    console.log(error);
                                });

                            }
                             previous_token=current_token;
                        }
                    }
                }
            }
        }
    });

//---------------- Pay button check -----------------
    screens.ActionpadWidget.include({
      renderElement: function() {
            this._super();
            var self = this;
            this.$('.pay').click(function(){
                var order = self.pos.get_order();
                var order_progress = order.order_progress;
                if(order.order_progress =="in_queue" || order.order_progress =="in_progress" ||order.order_progress =="done" )
                {

                         self.gui.show_popup('confirm',{
                            'title': _t('Are You Sure?'),
                            'body':  _t('Order isn\'t Served yet.Do you want to proceed with payment ?? '),
                            confirm: function(){
                                console.log("confirm");
                                self.gui.show_screen('payment');
                            },
                            cancel: function(){
                                console.log("cancel");
                            }
                        });
                }
            });
      }
    });

});