odoo.define('visio_pos_location_disc.pos_custom', function(require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var devices = require('point_of_sale.devices');

    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');
    var field_utils = require('web.field_utils');

    var round_di = utils.round_decimals;
    var round_pr = utils.round_precision;

    var ProductListWidgets = screens.ProductListWidget;
    var OrderWidgets = screens.OrderWidget;
    var ProductScreenWidgets = screens.ProductScreenWidget;



//---------------- Variables Declaration -----------------

    var QWeb = core.qweb;
    var _t = core._t;

//    PosModel.load_fields('product.template', 'pos_location');
    PosModel.load_fields('product.product', 'pos_location');

//---------------- Product click modifier -----------------
    ProductListWidgets.include({
      init: function(parent, options) {
            var self = this;
            this._super(parent,options);
            this.click_product_handler = function(){
                var product = self.pos.db.get_product_by_id(this.dataset.productId);
                console.log('clicked product info -> ',product);
                if(product.pos_location){
                    var current_shop = product.pos_location.find(element => element == self.pos.config.id);
                    if(current_shop)
                    {

                      console.log('allowed discount',product);
                      options.click_product_action(product);

                    }
                    else
                    {
                      product.product_disc = 0.0;
                      product.product_disc_percent = 0.0;

                      console.log(' not allowed discount',product);
                      options.click_product_action(product);

                    }
                }
                else{
                    options.click_product_action(product);
                }



            }

    },
    });
// ---------------- Order discount modifier ----------------
//    OrderWidgets.include({
//        set_value: function(val) {
//    	var order = this.pos.get_order();
//    	console.log('order.get_selected_orderline()',order.get_selected_orderline());
//    	if (order.get_selected_orderline()) {
//            var mode = this.numpad_state.get('mode');
//            if( mode === 'quantity'){
//                order.get_selected_orderline().set_quantity(val);
//            }else if( mode === 'discount'){
//                order.get_selected_orderline().set_discount(val);
//            }else if( mode === 'price'){
//                var selected_orderline = order.get_selected_orderline();
//                selected_orderline.price_manually_set = true;
//                selected_orderline.set_unit_price(val);
//            }
//            if (this.pos.config.iface_customer_facing_display) {
//                this.pos.send_current_order_to_customer_facing_display();
//            }
//    	}
//    },
//
//
//
//    });

// ---------------- Order discount modifier ----------------


});