# -*- coding: utf-8 -*-
# from odoo import http


# class VisioPosLocationDisc(http.Controller):
#     @http.route('/visio_pos_location_disc/visio_pos_location_disc/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/visio_pos_location_disc/visio_pos_location_disc/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('visio_pos_location_disc.listing', {
#             'root': '/visio_pos_location_disc/visio_pos_location_disc',
#             'objects': http.request.env['visio_pos_location_disc.visio_pos_location_disc'].search([]),
#         })

#     @http.route('/visio_pos_location_disc/visio_pos_location_disc/objects/<model("visio_pos_location_disc.visio_pos_location_disc"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('visio_pos_location_disc.object', {
#             'object': obj
#         })
