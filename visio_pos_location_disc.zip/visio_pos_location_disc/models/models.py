# -*- coding: utf-8 -*-

from odoo import models, fields, api


class visio_pos_location_disc(models.Model):
    _inherit = 'product.template'

    pos_location = fields.Many2many('pos.config', string="Pos Location", store=True)

