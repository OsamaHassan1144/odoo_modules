# -*- coding: utf-8 -*-
from odoo import http


class PosWorker(http.Controller):

    @http.route('/pos_worker/worker', auth='user')
    def update_order_delivered(self, **kw):
        print("update id usong controller")
        work_ide = kw['worker_id']
        work_order = kw['order_id']
        res = http.request.env['pos.order'].search([('pos_reference', '=', work_order)])

        res.worker_id = work_ide

#     @http.route('/pos_worker/pos_worker/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('pos_worker.listing', {
#             'root': '/pos_worker/pos_worker',
#             'objects': http.request.env['pos_worker.pos_worker'].search([]),
#         })

#     @http.route('/pos_worker/pos_worker/objects/<model("pos_worker.pos_worker"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pos_worker.object', {
#             'object': obj
#         })
