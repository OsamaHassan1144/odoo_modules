# -*- coding: utf-8 -*-

from odoo import models, fields, api
from functools import partial


class posorderinherit(models.Model):
    _inherit = 'pos.order'

    worker_id = fields.Many2one('pos.workers.salesmen', String="employee name")

    @api.model
    def create(self, values):
        res = super(posorderinherit, self).create(values)
        workerobj = self.env['pos.worker'].search([('order_nam', '=', res.pos_reference)])
        if workerobj:
            res.worker_id = workerobj.worker_id.id
        return res

    @api.model
    def read_order(self, args):
        pos_reference = args.get('pos_reference')
        res = self.search([('pos_reference', 'ilike', pos_reference)], order='id desc')
        if res:
            res = res[0]
            order_lines = []
            for obj in res.lines:
                line_data = {
                    'discount': obj.discount,
                    'id': obj.id,
                    'note': obj.note,
                    'pack_lot_ids': [],
                    'price_subtotal': obj.price_subtotal,
                    'price_subtotal_incl': obj.price_subtotal_incl,
                    'price_unit': obj.price_unit,
                    'product_id': obj.product_id.id,
                    'qty': obj.qty,
                    'tax_ids': [6, False, obj.tax_ids.ids]
                }
                line = [0, 0, line_data]
                order_lines.append(line)
            employees = []
            for obj in res.employees_ids:
                employees.append(obj.emp_id.id)
            payment_lines = []
            for obj in res.payment_ids:
                payment_line_data = {
                    'name': obj.payment_method_id.name,
                    'amount': obj.amount,
                    'id': obj.payment_method_id.id,
                    'payment_method_id': obj.payment_method_id.id,
                }
                payment_line = [0, 0, payment_line_data]
                payment_lines.append(payment_line)
            tax_details = []
            order = res
            car_details = {}
            if order.car_id:
                car_details = order.car_id.read(['vehicle_no', 'car_model', 'car_brand', 'car_model'])
                if car_details:
                    car_details = car_details[0]
                    if car_details.get('car_brand'):
                        car_details['brand_name'] = car_details['car_brand'][1]
            res = {
                'amount_paid': order.amount_paid,
                'amount_return': order.amount_return,
                'amount_tax': order.amount_tax,
                'amount_total': order.amount_total,
                'creation_date': order.create_date,
                'customer_count': 1,
                'employee_id': False,
                'fiscal_position_id': False,
                'floor_id': order.table_id.floor_id.id,
                'lines': order_lines,
                'partner_id': order.partner_id.id,
                'pos_reference': order.pos_reference,
                'pos_session_id': order.session_id.id,
                'session_id': order.session_id.id,
                'statement_ids': payment_lines,
                'table_id': order.table_id.id,
                'user_id': order.user_id.id,
                'uid': order.pos_reference.replace('Order ', '')
            }
            order_car = {}
            mbl = ""
            if order.car_id:
                order_car = order.car_id.read(['car_brand', 'car_model', 'vehicle_no', 'id'])
                if order_car:
                    order_car = order_car[0]
            cust_info = order.partner_id
            if cust_info.phone:
                mbl = cust_info.phone
            elif cust_info.mobile:
                mbl = cust_info.mobile
            res = {
                'order': res,
                'related': {
                    'name': order.name,
                    'car_reading_per_day': order.car_reading_per_day,
                    'reading_on_next_service': order.reading_on_next_service,
                    'current_reading': order.current_reading,
                    'km_for_next_service': order.km_for_next_service,
                    'date_of_next_service': order.date_of_next_service,
                    'table_name': order.table_id.name,
                    'selected_employees': employees,
                    'worker_name': order.worker_id.salesmen_name,
                    'currentCar': order_car,
                    'tax_details': tax_details,
                    'car_details': car_details,
                },
                'partner_info': {
                    'name': cust_info.name,
                    'cell': mbl,
                    'address': cust_info.contact_address,
                }
            }
            return res
        else:
            'No order found'


class pos_worker(models.Model):
    _name = 'pos.worker'

    order_nam = fields.Char(String="order name", store=True)
    worker_id = fields.Many2one('pos.workers.salesmen', String="employee name")

    @api.model
    def create_order(self, data_list):
        my_order = data_list['order_nam']
        res = self.env['pos.worker'].search([('order_nam', '=', my_order)])
        if not res:
            res = super(pos_worker, self).create(data_list)
        print("hellos", res)


class pos_salesmen(models.Model):
    _name = 'pos.workers.salesmen'
    _rec_name = "salesmen_name"

    salesmen_name = fields.Char(String="Salesmen name")

    # @api.model
    # def create(self, values):
    #     res = super(pos_salesmen, self).create(values)


class pos_worker_loc(models.Model):
    _inherit = 'pos.config'

    worker_info = fields.Many2many('pos.workers.salesmen', String="Select Salesmen")
