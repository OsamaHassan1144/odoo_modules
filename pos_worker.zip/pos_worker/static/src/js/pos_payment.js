odoo.define('pos_worker.update_id', function (require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require ('web.Widget');
    var ajax = require ('web.ajax');



    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PaymentScreenWidget = screens.PaymentScreenWidget;
    var ChromeHeaderWidget=chrome.HeaderButtonWidget;
    var _t = core._t;




  PaymentScreenWidget.include({
        show: function() {
            var self = this;
            this._super();
            var order = this.pos.get_order();
            if(order.orderlines.length >= 1)
            {
                if(order.worker_id)
                {
                    var cur_order = order.name;
                    var prev_order;
                    if(cur_order != prev_order)
                    {
                         let new_data={
                            'order_nam' :order.name,
                            'worker_id' :order.worker_id,
                         }
                         rpc.query({
                            model: 'pos.worker',
                            method: 'create_order',
                            args: [new_data],
                         }).then(function() {
                         }).catch(function(reason) {
                            var error = reason.message;
                            console.log(error);
                         });
                         prev_order=cur_order;
                    }
                    else
                    {
                        console.log('already created');
                    }

                }
                else
                {
                    self.gui.show_screen('products');
                    Swal.fire
                    ({
                          icon: 'warning',
                          title: 'Worker not selected',
                          text: "Please select worker first !",
                          showConfirmButton: false,
                          timer: 10000
                    });
                }
            }
        }

    });
});
