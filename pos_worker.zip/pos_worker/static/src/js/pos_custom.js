odoo.define('pos_worker.pos_custom', function(require) {
    "use strict";

    var ajax = require('web.ajax');

    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');
    var field_utils = require('web.field_utils');
    var OrderSelectorWidgets = chrome.OrderSelectorWidget;
    var ProductListWidgets = screens.ProductListWidget;
    var ProductScreenWidgets = screens.ProductScreenWidget;
    var worker_id;
    var worker_name;

    var round_di = utils.round_decimals;
    var round_pr = utils.round_precision;


//---------------- Variables Declaration -----------------

    var QWeb = core.qweb;
    var _t = core._t;

    PosModel.load_models({
        model: 'pos.workers.salesmen',
        fields: ['id', 'salesmen_name'],


        loaded: function(self, workers) {

            var my_var=[];

            var i = 0;
            var j = 0;
            while(j < workers.length)
            {
                if(workers[j].id == self.config.worker_info[i])
                {
                    my_var.push(workers[j]);
                    i++;
                }
                j++
            }
            self.workers = my_var;
        },
    });



 PosModel.Order = PosModel.Order.extend({
  get_worker_id: function() {
        var worker_id = $(".worker_select option:selected").val();
        var id_w = parseInt(worker_id);
        return id_w;
  },
  get_worker_name: function() {
        var worker_name = $(".worker_select option:selected").text().trim();
        var name_w = String(worker_name);
        return name_w;
  },
 });



//---------------- Worker Selection widget -----------------
     var WorkerSelectDropdownListWidget = screens.ActionButtonWidget.extend({
        template: 'worker_select_dropdown',
        button_click: function() {
            var self = this;
            self.order_function();
        },
        order_function: function() {

            var order = this.pos.get_order();
            var this_order = order.name;
            worker_id = $(".worker_select option:selected").val();
            this.pos.get_order().worker_id = parseInt(worker_id);
            worker_name = $(".worker_select option:selected").text().trim();
            this.pos.get_order().worker_name =String(worker_name);


        },

});

     screens.define_action_button({

        'name': 'worker_select_dropdown',
        'widget': WorkerSelectDropdownListWidget,

    });
//---------------- Modifying orderselection widget -----------------
 OrderSelectorWidgets.include({

         neworder_click_handler: function(event, $el) {
            this.pos.add_new_order();
            $('.worker_select').prop('selectedIndex',0);
         },
          floor_button_click_handler: function(){
                this.pos.set_table(null);
                $('.worker_select').prop('selectedIndex',0);
        },

    });

//---------------- Modifying next after validation widget  * -----------------

 screens.ReceiptScreenWidget.include({
        click_next: function(ev) {
            this._super();
            $('.worker_select').prop('selectedIndex',0);
        }
    });


//---------------- Modifying product widget  * -----------------

ProductScreenWidgets.include({

    show: function(reset){
        this._super();
        $('.worker_select').prop('value',this.pos.get_order().worker_id);

    },

});
});

