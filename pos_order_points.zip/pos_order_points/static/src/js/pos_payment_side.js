odoo.define('pos_order_points.DisplayButton', function (require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');
    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require ('web.Widget');
    var ajax = require ('web.ajax');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PaymentScreenWidget = screens.PaymentScreenWidget;
    var ChromeHeaderWidget=chrome.HeaderButtonWidget;
    var _t = core._t;

    var pay_id=1;
    var total_redeem_pts = 0;
    var order_orderid;



  PaymentScreenWidget.include({

     validate_order: function(force_validation) {
        var order = this.pos.get_order();
        var partner = order.get_client();
        if(!order.order_id)
        {
            order.order_id = order.uid;
            order_orderid= order.order_id;
        }
        else
        {
            order_orderid = order.order_id;
        }
        if (this.order_is_valid(force_validation))
        {
            if (order && partner)
            {
                    console.log("paying from points");
                    var customer =order.get_client();
                    var customer_name =customer.name;
                    var points = customer.points_earned;
                    var order_points = order.get_total_points();
                    var order_redeem_points = order.get_total_redeem_points();
                    var total_points = order_points - order_redeem_points;
                    var tot_points = points + total_points
                    var values_list={
                    'customer_name':customer_name,
                    'update_points':tot_points,
                    }
                    rpc.query({
                        model: 'res.partner',
                        method: 'updating_points',
                        args: [values_list],
                    }).then(function() {
                    }).catch(function(reason) {
                        var error = reason.message;
                        console.log(error);
                    });
                 console.log("paying for points");
                 let input_data = {
                    'orderid' :order_orderid,
                     }
                var options = {
                    url: '/pos_order_points/token_progress',
                    data: input_data,
                    dataType: 'JSON',
                    success: function(data) {
                        if (typeof(data) == 'string') {
                        }
                    },
                    error: function(a) {
                        console.log(a.responseText);
                    }
                }
                let order_data = localStorage.getItem('order_value -'+ order.uid);
                if(order_data)
                 {
                   localStorage.removeItem('order_value -'+order.uid);
                 }
                $.ajax(options);
                  let new_data={
                    'orderid' :order.order_id,
                }
                rpc.query({
                    model: 'pos.points',
                    method: 'validate_order_timestamp',
                    args: [new_data],
                }).then(function() {
                }).catch(function(reason) {
                    var error = reason.message;
                    console.log(error);
                });
                 total_redeem_pts=0;
                 this.pos.get_order().redeem_pts = total_redeem_pts;
                 this.finalize_validation();
            }
            else
            {

                 console.log("paying for points");
                 let input_data = {
                    'orderid' :order_orderid,
                     }
                var options = {
                    url: '/pos_order_points/token_progress',
                    data: input_data,
                    dataType: 'JSON',
                    success: function(data) {
//                        if (typeof(data) == 'string') {
//                        }

                    },
                    error: function(a) {
                        console.log(a.responseText);
                    }
                }
                let order_data = localStorage.getItem('order_value -'+ order.uid);
                if(order_data)
                 {
                   localStorage.removeItem('order_value -'+order.uid);
                 }
                $.ajax(options);
                  let new_data={
                    'orderid' :order.order_id,
                }
                rpc.query({
                    model: 'pos.points',
                    method: 'validate_order_timestamp',
                    args: [new_data],
                }).then(function() {
                }).catch(function(reason) {
                    var error = reason.message;
                    console.log(error);
                });

                 total_redeem_pts=0;
                 this.pos.get_order().redeem_pts = total_redeem_pts;
                 this.finalize_validation();

            }

        }

    },
     show: function() {
        this._super();
        var order = this.pos.get_order();
        console.log("datasss",order);
        this.$('.js_points').text( order ? "Earned Points  " + order.get_total_points() : _t('N/A') );
        this.$('.js_redeem_points').text( order ? "Redeem Points  " + order.get_total_redeem_points() : _t('N/A') );
    },

   });

});
