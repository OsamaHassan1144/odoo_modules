odoo.define('pos_order_points.pos_inherit', function(require) {
    "use strict";

    var ajax = require('web.ajax');
    var BarcodeParser = require('barcodes.BarcodeParser');
    var BarcodeReader = require('point_of_sale.BarcodeReader');
    var chrome = require("point_of_sale.chrome");
    var PosDB = require('point_of_sale.DB');
    var devices = require('point_of_sale.devices');

    var concurrency = require('web.concurrency');
    var config = require('web.config');
    var core = require('web.core');
    var field_utils = require('web.field_utils');
    var rpc = require('web.rpc');
    var session = require('web.session');
    var time = require('web.time');
    var utils = require('web.utils');
    var core = require('web.core');
    var Widget = require('web.Widget');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');

    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');
    var PosBaseWidget = require('point_of_sale.BaseWidget');
    var PosModel = require('point_of_sale.models');
    var field_utils = require('web.field_utils');

    var round_di = utils.round_decimals;
    var round_pr = utils.round_precision;
    var ProductScreenWidgets = screens.ProductScreenWidget;
    var ProductListWidgets = screens.ProductListWidget;
    var ProductCategoriesWidgets = screens.ProductCategoriesWidget;
    var ClientListScreenWidget = screens.ClientListScreenWidget;
    var OrderWidgetobj = screens.OrderWidget;
    var OrderSelectorWidgets = chrome.OrderSelectorWidget;

//---------------- Variables Declaration -----------------
    var CurrentOrder;
    var PreviousOrder;
    var c_time;
    var current_table_name;
    var torder;
    var saved_o = 0;
    var pos_info;
    var customer_name;
    var shop_name;
    var shop_session_login_number;
    var shop_session_id;
    var queue_lines = [];
    var current_queue_id;
    var val_list;
    var line;
    var Order_ID;
    var current_order_token;
    var length_orderline;
    var e_time;
    var pos_table;
    var Progress;
    var order_type;
    var products;
    var product_message;
    var R_receipt;
    var idee;
    var our_data;
    var current_order;
    var fetch_status="";
    var fetch_type="";

    var all_pro = false;
    var ol_pro =false;
    var popup_open = false;
    var total_redeem_pts = 0;
    var int_cate_id;

    var exports = {};
    var QWeb = core.qweb;
    var _t = core._t;

    PosModel.load_fields('res.partner', 'points_earned');
    PosModel.load_fields('res.partner', 'car_num');
    PosModel.load_fields('product.product', 'reward_points');
    PosModel.load_fields('product.product', 'product_color');
    PosModel.load_fields('product.product', 'redeem_points');
    PosModel.load_fields('product.product', 'instruction_select');
    PosModel.load_fields('product.product', 'distinct_product');
    PosModel.load_fields('product.product', 'parent_int_categ');
    PosModel.load_fields('product.product', 'seq_num');

    PosModel.load_models({
        model: 'pos.message',
        fields: ['id', 'msg_text'],

        loaded: function(self, messages) {
            var my_var=[];
            var i = 0;
            var j = 0;
            while(j < messages.length)
            {
                if(messages[j].id )
                {
                    my_var.push(messages[j]);
                    i++;
                }
                j++
            }
            self.my_messages = my_var;
        },

     });

    PosDB.include({
            init: function(options) {
            options = options || {};
            this.name = options.name || this.name;
            this.limit = options.limit || this.limit;

            if (options.uuid) {
                this.name = this.name + '_' + options.uuid;
            }
            this.cache = {};

            this.product_by_id = {};
            this.product_by_barcode = {};
            this.product_by_category_id = {};

            this.partner_sorted = [];
            this.partner_by_id = {};
            this.partner_by_barcode = {};
            this.partner_search_string = "";
            this.partner_write_date = null;

            this.category_by_id = {};
            this.root_category_id = 0;
            this.category_products = {};
            this.category_ancestors = {};
            this.category_childs = {};
            this.category_parent = {};
            this.category_search_string = {};
        },
            get_parent_categ_ingredient: function(click_parent_int_categ){
              var pos_catego_k = this.db;
              var pos_catego = this.category_by_id;
              var int_id;
              for(var i = 0; i < 100; i ++)
              {
                if(pos_catego[i])
                {
                    if(pos_catego[i].name == "Ingredient")
                    {
                        int_id = pos_catego[i].id;
                    }
                }
              }
              console.log(int_id);


                var all_product_ids  = this.product_by_category_id[int_id];
                var product_require=[]
                if(all_product_ids)
                {
                      for(var i = 0; i<all_product_ids.length ;i++)
                {
                      if( this.product_by_id[all_product_ids[i]].parent_int_categ.length > 0)
                      {

                          if( this.product_by_id[all_product_ids[i]].parent_int_categ.length == 1)
                          {
                             if( this.product_by_id[all_product_ids[i]].parent_int_categ[0] == click_parent_int_categ )
                             {
                                product_require.push(this.product_by_id[all_product_ids[i]]);
                             }
                          }
                          else if(this.product_by_id[all_product_ids[i]].parent_int_categ.length > 1)
                          {
                            for(var j = 0; j < this.product_by_id[all_product_ids[i]].parent_int_categ.length ; j++)
                            {
                                 if( this.product_by_id[all_product_ids[i]].parent_int_categ[j] == click_parent_int_categ )
                                 {
                                    product_require.push(this.product_by_id[all_product_ids[i]]);
                                 }
                            }
                          }
                      }
                }


                }
//                console.log("my_items",product_require);
                return product_require;

            },

    });


    chrome.OrderSelectorWidget.include({
    floor_button_click_handler: function(){
        this.pos.set_table(null);
    },
    renderElement: function(){
        var self = this;
        this._super();
       if (this.pos.config.iface_floorplan) {
                if (this.pos.get_order()) {
                    if (this.pos.table && this.pos.table.floor)
                    {
                        var pos_order = this.pos.get_order();
                        let order_data = localStorage.getItem('order_value -'+ pos_order.uid);
                        if(order_data)
                        {
                            var stringify = JSON.parse(order_data);
                            pos_order.order_id = stringify['order_id'];
                            pos_order.order_progress = stringify['order_progress'];
                            pos_order.order_type = stringify['order_type'];

                        }
                    }
                }
       }


    },
});

//---------------- Generate redemption Popup -----------------

    var POSRedemptionPopup = PosBaseWidget.extend({
        template: 'Redemption_Popup_POS',
        init: function(parent, args) {
            this._super(parent, args);
            this.parameter = "";
        },
        start: function() {
            this._super();
            var self = this;
            this.getParent().on("view_content_has_changed", this, function() {
                self.render_value();
            });
        },
        events: {
            'click .button.cancel': 'click_cancel',
            'click .button.done-select': 'click_confirm',
            'click .button.all-select': 'click_all_product',
            'click .button.ol-select': 'click_ol_product',
        },

        show: function(options) {
            options = options || {};
            this._super(options);
            this.renderElement();

        },


        close: function() {

        },
         click_all_product: function(){
            var food_products = this.pos.db.get_product_by_category(5);
            var drink_products = this.pos.db.get_product_by_category(4);
            var all_products = food_products.concat(drink_products);
            var sel_customer= this.pos.get_client();
            var contents = this.$el[0].querySelector('.redemption-list-contents');
            var temp="";
            contents.innerHTML = "";
             for(var i = 0; i < all_products.length; i++){
                var products = all_products[i];
                if(products.reward_points <= sel_customer.points_earned)
                {
                    var products_line_html = QWeb.render('RedemptionAllProduct',{widget: this, products:products});
                    var products_line = document.createElement('tbody');
                    products_line.innerHTML = products_line_html;
                    products_line = products_line.childNodes[1];
                    contents.appendChild(products_line);
                }
            }
            all_pro= true;
            ol_pro= false;

        },
         click_ol_product: function(){

            var ol_products = this.pos.get_order().get_orderlines() ;
            var sel_customer= this.pos.get_client();
            var contents = this.$el[0].querySelector('.redemption-list-contents');
            var temp="";
            contents.innerHTML = "";
             for(var i = 0; i < ol_products.length; i++){
                var products   = ol_products[i];
                  if(products.product.reward_points <= sel_customer.points_earned && products.product.categ.name != "Ingredient")
                {
                    var products_line_html = QWeb.render('RedemptionSelectProduct',{widget: this, products:products});
                    var products_line = document.createElement('tbody');
                    products_line.innerHTML = products_line_html;
                    products_line = products_line.childNodes[1];
                    contents.appendChild(products_line);
                }
            }
            all_pro= false;
            ol_pro= true;

        },

        click_confirm: function() {
            var self = this;
            var current_order = self.pos.get_order();
            var product_list = [];
            $.each($("input[name='check-product']:checked"), function(){
                product_list.push($(this).attr("data-id") );
            });
             for(var i = 0; i < product_list.length; i++){
                var order   = product_list[i];
                var product = self.pos.db.get_product_by_id(order);
                if(all_pro && !ol_pro)
                {
                    current_order.add_product(product,{price:0});
                    total_redeem_pts += product.redeem_points;
//                    $(current_order.orderlines.models[i].node).trigger('click');
                }
                else if (ol_pro && !all_pro)
                {


                    for(var j = 0; j < current_order.orderlines.models.length ; j++ )
                    {
                        if( current_order.orderlines.models[j].product.id == order && current_order.orderlines.models[j].product.categ.name != "Ingredient")
                        {
                            current_order.orderlines.models[j].price = 0;
                            total_redeem_pts += current_order.orderlines.models[j].product.redeem_points;
                            $(current_order.orderlines.models[j].node).trigger('click');

                        }
                    }
                }
            }
            this.gui.close_popup();
        },
        click_cancel: function() {
            this.gui.close_popup();
        },
    });
    gui.define_popup({
        name: 'Redemption_Popup_POS',
        widget: POSRedemptionPopup
    });

//---------------- Generate OrderType Popup -----------------

    var POSOrderTypePopup = PosBaseWidget.extend({
        template: 'Ordertype_Popup_POS',
        init: function(parent, args) {
            this._super(parent, args);
            this.parameter = "";
        },
        start: function() {
            this._super();
            var self = this;
            this.getParent().on("view_content_has_changed", this, function() {
                self.render_value();
            });

        },
        events: {
            'click .button.cancel': 'click_cancel',
            'click .button.done-select': 'click_confirm',
        },
        show: function(options) {
            options = options || {};
            this._super(options);
            this.renderElement();
            this.parameter = options.parameter;
        },
        close: function() {

        },

        click_confirm: function() {
//
//           if($("input[name='ordertype']:checked").val())
//           {
//                var self = this;
//                var orders = this.pos.get_order();
//                var pos_orders = self.pos.get('selectedOrder');
//                var selected_type = $("input[name='ordertype']:checked").val();
//                $('.order_type').prop('value',selected_type);
//                torder = self.pos.get_order();
//                pos_table = self.pos.table;
//                var pos_orders = self.pos.get('selectedOrder');
//                var line = this.pos.get_order().get_selected_orderline();
//                pos_info=self.pos.pos_session;
//                this.pos.get_order().order_progress = "live";
//
//                if(this.pos.get_client())
//                {
//                    customer_name=this.pos.get_client().name;
//                }
//                else
//                {
//                    customer_name=torder.cid;
//                }
//                if(this.pos.get_order().table)
//               {
//                    shop_session_id = this.pos.config.id;
//                    shop_session_login_number = pos_info.login_number;
//                    shop_name = torder.pos.config.name;
//                    current_table_name = torder.table.name;
//                    CurrentOrder = customer_name;
//                    length_orderline=torder.orderlines.length;
//                    Progress = torder.order_progress;
//                    c_time = torder.creationtime;
//                    fetch_status="live";
//                    shop_name = torder.pos.config.name;
//
//               }
//               else
//               {
//                    shop_session_id = this.pos.config.id;
//                    shop_session_login_number = pos_info.login_number;
//                    shop_name = torder.pos.config.name;
//                    CurrentOrder = customer_name;
//                    current_table_name="";
//                    length_orderline=torder.orderlines.length;
//                    Progress = torder.order_progress;
//                    c_time = torder.creationtime;
//                    fetch_status="live";
//                    shop_name = torder.pos.config.name;
//
//               }
//                    if (!torder.order_id) {
//
//                        torder.order_id=torder.uid;
//                        Order_ID =torder.order_id;
//                        order_type = $(".order_type option:selected").val();
//                        var today = new Date();
//                        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
//                        var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
//                        var dateTime = date+' '+time;
//                        torder.order_type = order_type;
//                        torder.product_list = queue_lines;
//                        torder.order_progress = "live";
//                        Swal.fire
//                         ({
//                              icon: 'success',
//                              title: 'Order Created ',
//                              showConfirmButton: false,
//                              timer: 5000,
//                         });
//                         PreviousOrder = CurrentOrder;
////                         var m = torder.orderlines.models;
//                         val_list = {
//                                's_id':shop_session_id,
//                                's_login_number':shop_session_login_number,
//                                's_name':shop_name,
//                                'table_name': current_table_name,
//                                'order_id': Order_ID,
//                                'order_type': order_type,
//                                'partner_id': customer_name,
//                                'pos_order_id': torder.name,
//                                'timestamp_order': dateTime,
//                                'order_progress': torder.order_progress,
//                         };
//                         let order_data = localStorage.getItem('order_value -'+ torder.uid);
//                         if(!order_data)
//                         {
//                           var str_data = JSON.stringify(val_list);
//                           localStorage.setItem('order_value -' + torder.uid, str_data);
//                         }
//
//                        rpc.query({
//                            model: 'pos.points',
//                            method: 'create_order',
//                            args: [val_list],
//                        }).then(function(res) {
//
//                        }).catch(function(reason) {
//                            var error = reason.message;
//                        });
////                        saved_o=1;
//
//
//                    }
////                    else
////                    {
////                        Swal.fire
////                        ({
////                              icon: 'error',
////                              title: 'This Order is already Created',
////                              showConfirmButton: false,
////                              timer: 10000
////                        });
////                    }

//                this.gui.close_popup();
//           }
//           else
//           {
//                alert("select one option");
//           }
        },
        click_cancel: function() {
            this.gui.close_popup();
        },
    });
    gui.define_popup({
        name: 'Ordertype_Popup_POS',
        widget: POSOrderTypePopup
    });




//---------------- Message Screen Widget -----------------

    var MessagesQueueWidget = screens.ScreenWidget.extend({
        template: 'MessageScreenWidget',

        show: function(){
            var self = this;
            this._super();
            var self = this;
            self.pos.get_order().get_selected_orderline().message="";
            var line = this.pos.get_order().get_selected_orderline();
            var current_order = self.pos.get_order();
            var selected_messages = [];
            var all_message = this.pos.my_messages;
            var product_message = line.product.instruction_select;
            var my_var=[];
                var i = 0;
                var j = 0;
                while(j < all_message.length)
                {
                    if(all_message[j].id == product_message[i])
                    {
                        my_var.push(all_message[j]);
                        i++;
                    }
                    j++
                }
            self.render_list(my_var);

            this.$('.messages-list-contents').on('click', '.Messages-option-line', function(event){
                  console.log('clicked',String($(this).data('id')),$(this));
                  self.msg_select(event,$(this),String($(this).data('id')));
            });
            this.$('.confirm').off().click(function(){
                if(line)
                {
                    console.log('confirm',$(".Messages-option-line"))
                    $.each($(".Messages-option-line"), function(){
                       if($(this).hasClass('highlights') )
                       {
                        selected_messages.push(String($(this).data('id')));
                       }
                    });
                    console.log("selected_messages",selected_messages);
                    for(var i = 0; i < selected_messages.length;i++)
                    {
                        if (line.message){
                            line.message =  selected_messages[i] + " , " + line.message ;
                        }
                        else{
                            line.message =  selected_messages[i] ;
                        }


                    }
                    line.message_array = selected_messages;
                    console.log(current_order.orderlines);
                    $(current_order.orderlines.models[0].node).trigger('click');



                     torder.order_id=torder.uid;
                            Order_ID =torder.order_id;
                            order_type = $(".order_type option:selected").val();
                             val_list = {

                                    'order_id': Order_ID,
                                    'partner_id': customer_name,
                                    'order_type': order_type,
                             };
                             var m = torder.orderlines.models;
                             var orderlineslist = []
                            rpc.query({
                                model: 'pos.points',
                                method: 'update_order',
                                args: [val_list ],
                            }).then(function(res) {
                                 for (var i = 0; i < m.length; i++) {
                                        line = {
                                            'queue_id': res,
                                            'product_name': m[i].product.display_name,
                                            'product_quantity': m[i].quantity,
                                            'product_message': m[i].message ? m[i].message :  m[i].message="",
                                            'product_category': m[i].product.pos_categ_id[1],
                                            'product_colored': m[i].product.product_color[1] ? m[i].product.product_color[1] :  m[i].product.product_color="",
                                        }
                                        orderlineslist.push(line)
                                 }
                                 console.log('orderlineslist',orderlineslist);
                                            rpc.query({
                                                model: 'pos.points.line',
                                                method: 'update_existing_lines',
                                                args: [orderlineslist],
                                            }).then(function() {
                                                console.log("Success")
                                            }).catch(function(reason) {
                                                var error = reason.message;
                                                conval_listsole.log(error);
                                            });
                            }).catch(function(reason) {
                                var error = reason.message;
                            });

//                    OrderWidgetobj.rerender_orderline(line);
//                    if ($(current_order.orderlines.models[1].node)){
//                        $(current_order.orderlines.models[1].node).trigger('click');
//                    }
//                    else{
//                        $(current_order.orderlines.models[0].node).trigger('click');
//                    }

                }
                else
                {
                    alert("Alert");
                }
//                $('.messages-list-contents').find('.highlights').removeClass('highlights');

                self.gui.back();
                });
            this.$('.back').off().click(function(){
                self.gui.back();

            });

        },
        render_list: function(messages){
               var contents = this.$el[0].querySelector('.messages-list-contents');
                var temp="";
                contents.innerHTML = "";
                for(var i = 0; i < messages.length; i++){
                    var msg   = messages[i];
                    var msg_line_html = QWeb.render('Messages',{widget: this, msg:msg});
                    var msg_line = document.createElement('tbody');
                    msg_line.innerHTML = msg_line_html;
                    msg_line = msg_line.childNodes[1];
                    contents.appendChild(msg_line);
                }
//                  console.log('in confirm', $('.Messages-option-line'));
//                      $.each($('tr'), function(){
//                          console.log('for_loop',$(this))  ;
//                          if($(this).hasClass('highlights','lowlights') ||$(this).hasClass('highlights') || $(this).hasClass('lowlights') )
//                          {
//                                $(this).removeClass('highlights');
//                                $(this).removeClass('lowlights');
//                          }
//
//                        });

        },
        msg_select: function(event,$line,id){

//            console.log('line1', this.$('.Messages-option-line'));
//            this.$('.Messages-option-line.lowlights.highlights').removeClass(' highlights');
            console.log('line',  $line);
//            this.$('.Messages-option-line.highlights.lowlights').removeClass(' lowlights');

//            $line.removeClass('lowlights');
//            this.$('.Messages-option-line .lowlights').removeClass(' lowlights');

//            this.$('.Messages-option-line .highlights').removeClass('highlights');
//            if ( $line.hasClass('highlights') ){
//                console.log('if highlights');
//                $line.removeClass('highlights');
//                $line.addClass('lowlights');
//                $line.css('background-color', '');

//                ($line).style.backgroundColor = " ";
//                this.display_client_details('hide',partner);
//                this.new_client = null;
//                this.toggle_save_button();
//            }else{
                console.log('else');
                this.$('.Messages-option-line .highlights').removeClass('highlights');
//                 $line.removeClass('lowlights');
                $line.addClass('highlights');
                $line.css('background-color', 'rgb(110,200,155)');
//                $line.style.backgroundColor = "rgb(110,200,155)";
//                var y = event.pageY - $line.parent().offset().top;
//                this.display_client_details('show',partner,y);
//                this.new_client = partner;
//                this.toggle_save_button();
//            }
    },


    });
    gui.define_screen({ name:'messagesqueue', widget: MessagesQueueWidget, });



//---------------- Generate Message Popup -----------------

    var POSMessagePopup = PosBaseWidget.extend({
        template: 'Message_Popup_POS',
//        init: function(parent, args) {
//            this._super(parent, args);
//            this.parameter = "";
//        },
//        start: function() {
//            this._super();
//            var self = this;
//            this.getParent().on("view_content_has_changed", this, function() {
//                self.render_value();
//            });
//        },
//        events: {
//            'click .button.cancel': 'click_cancel',
//            'click .button.done-select': 'click_confirm',
//        },
//         render_list: function(messages){
//            var contents = this.$el[0].querySelector('.messages-list-contents');
//            var temp="";
//            contents.innerHTML = "";
//            for(var i = 0; i < messages.length; i++){
//                var msg   = messages[i];
//                var msg_line_html = QWeb.render('Message',{widget: this, msg:msg});
//                var msg_line = document.createElement('tbody');
//                msg_line.innerHTML = msg_line_html;
//                msg_line = msg_line.childNodes[1];
//                contents.appendChild(msg_line);
//            }
//        },
//        show: function(options) {
//            options = options || {};
//            this._super(options);
//            this.renderElement();
//            var self=this;
//            self.pos.get_order().get_selected_orderline().message="";
//            this.parameter = options.parameter;
//             rpc.query({
//                model: 'pos.message',
//                method: 'get_all_messages',
//                args: [],
//            }).then(function(messages) {
//                self.render_list(messages);
//            });
//        },
//        close: function() {
//        },
//
//        click_confirm: function() {
//            var self = this;
//            var line = this.pos.get_order().get_selected_orderline();
//            var current_order = self.pos.get_order();
//            var selected_messages = [];
//
//            if(line)
//            {
//                $.each($("input[name='check-message']:checked"), function(){
//                    selected_messages.push($(this).attr("data-message"));
//                });
//                for(var i = 0; i < selected_messages.length;i++)
//                {
//                    line.message = selected_messages[i] + " , " + line.message ;
//                     $(current_order.orderlines.models[i].node).trigger('click');
//
//                }
//            }
//            else
//            {
//                alert("no orderline selected / present");
//            }
//            this.gui.close_popup();
//        },
//        click_cancel: function() {
//            this.gui.close_popup();
//        },
    });
    gui.define_popup({
        name: 'Message_Popup_POS',
        widget: POSMessagePopup
    });

//---------------- Generate Ingredient Popup -----------------

    var POSIngredientPopup = PosBaseWidget.extend({
        template: 'Ingredient_Popup_POS',
//        init: function(parent, args) {
//            this._super(parent, args);
//            this.parameter = "";
//        },
//        start: function() {
//            this._super();
//            var self = this;
//            this.getParent().on("view_content_has_changed", this, function() {
//                self.render_value();
//            });
//        },
//        events: {
//            'click .button.cancel': 'click_cancel',
//            'click .button.done-select': 'click_confirm',
//        },
//        show: function(options) {
//            options = options || {};
//            this._super(options);
//            this.renderElement();
//            this.parameter = options.parameter;
//            var ingredient_list = this.pos.db.get_product_by_category(6);
//            var contents = this.$el[0].querySelector('.ingredients-list-contents');
//            var temp="";
//            contents.innerHTML = "";
//            for(var i = 0; i < ingredient_list.length; i++){
//                var products   = ingredient_list[i];
//                var products_line_html = QWeb.render('IngredientsProduct',{widget: this, products:products});
//                var products_line = document.createElement('tbody');
//                products_line.innerHTML = products_line_html;
//                products_line = products_line.childNodes[1];
//                contents.appendChild(products_line);
//            }
//
//        },
//        close: function() {
//
//        },
//
//        click_confirm: function() {
//            var self = this;
//            var line = this.pos.get_order().get_selected_orderline();
//            var orders = this.pos.get_order();
//            var poss = this.pos.db;
//            var pro = this.pos.db.get_product_by_category(33);
//            var current_order = self.pos.get_order();
//            var ingredient = [];
//            $.each($("input[name='check-ingredient']:checked"), function(){
//                ingredient.push($(this).attr("data-id") );
//            });
//             for(var i = 0; i < ingredient.length; i++){
//                var order   = ingredient[i];
//                var product = self.pos.db.get_product_by_id(order);
//                current_order.add_product(product);
//            }
//             this.gui.close_popup();
//
//
//
//        },
//        click_cancel: function() {
//            this.gui.close_popup();
//        },
    });
    gui.define_popup({
        name: 'Ingredient_Popup_POS',
        widget: POSIngredientPopup
    });

//---------------- Generate Message Button -----------------
    var MessageButton = screens.ActionButtonWidget.extend({
        template: 'message_button',
        button_click: function(){
              var self = this;
              var line = self.pos.get_order().get_selected_orderline();
              if(line)
              {
                self.messagelist_function();
              }
              else
              {
                 alert("Select a orderline");
              }
         },
         messagelist_function: function(){
            this.gui.show_screen('messagesqueue');
         },
    });
    screens.define_action_button({
        'name': 'message_button',
        'widget': MessageButton,
    });

//---------------- Generate Order_ID Button -----------------
    var SaveButton = screens.ActionButtonWidget.extend({
        template: 'save_button',
        button_click: function() {
            var self = this;
            torder = self.pos.get_order();
            pos_table = self.pos.table;
            var pos_orders = self.pos.get('selectedOrder');
            var line = this.pos.get_order().get_selected_orderline();
            pos_info=self.pos.pos_session;
            if(this.pos.get_client())
            {
                customer_name=this.pos.get_client().name;
            }
            else
            {
                customer_name="";
            }
            if(this.pos.get_order().table)
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                current_table_name = torder.table.name;
                CurrentOrder = customer_name;
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                fetch_status="open";
                shop_name = torder.pos.config.name;
                self.order_save_function();

           }
           else
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                CurrentOrder = customer_name;
                current_table_name="";
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                fetch_status="open";
                shop_name = torder.pos.config.name;
                self.order_save_function();

           }
        },
        order_save_function: function() {

                            torder.order_id=torder.uid;
                            Order_ID =torder.order_id;
                            order_type = $(".order_type option:selected").val();
                             val_list = {

                                    'order_id': Order_ID,
                                    'partner_id': customer_name,
                                    'order_type': order_type,
                             };
                             var m = torder.orderlines.models;
                            rpc.query({
                                model: 'pos.points',
                                method: 'update_order_status',
                                args: [val_list ],
                            }).then(function(res) {
//                                 for (var i = 0; i < m.length; i++) {
//                                            line = {
//                                                'queue_id': res,
//                                                'product_name': m[i].product.display_name,
//                                                'product_quantity': m[i].quantity,
//                                                'product_message': m[i].message ? m[i].message :  m[i].message="",
//                                                'product_category': m[i].product.pos_categ_id[1],
//                                                'product_colored': m[i].product.product_color[1] ? m[i].product.product_color[1] :  m[i].product.product_color="",
//                                            }
//                                            rpc.query({
//                                                model: 'pos.points.line',
//                                                method: 'create_queue_order',
//                                                args: [line],
//                                            }).then(function() {
//                                                console.log("Success")
//                                            }).catch(function(reason) {
//                                                var error = reason.message;
//                                                console.log(error);
//                                            });
//                                 }
                            }).catch(function(reason) {
                                var error = reason.message;
                            });
                              Swal.fire
                        ({
                              icon: 'success',
                              title: ' Order Changes  Saved',
                              showConfirmButton: false,
                              timer: 1000
                        });
                            saved_o=1;

        },
    });
    screens.define_action_button({

        'name': 'save_button',
        'widget': SaveButton,

    });

//--------------- Points redemption  button ----------------
    var PointsRedemptionButton = screens.ActionButtonWidget.extend({
        template: 'customer_points_redeem_button',
        button_click: function() {
            var self = this;
            var sel_customer= this.pos.get_client();
            var current_order= this.pos.get_order();
            var point_limit = this.pos.config.points_cap;
            var line_select = this.pos.get_order().get_selected_orderline();
            if(sel_customer)
            {
                if(sel_customer.points_earned >= point_limit )
                {
                     if( line_select.price != 0 )
                     {
                         self.calculate_popup_function();

                     }
                }
            }
            else
            {
                 Swal.fire
                       ({
                              icon: 'error',
                              title: 'Customer not Selected',
                              text: "Please select a customer",
                              showConfirmButton: false,
                              timer: 1000
                       });
            }

        },
       calculate_popup_function: function() {


                var sel_customer = this.pos.get_client();
                var current_order = this.pos.get_order();


                if(total_redeem_pts < = sel_customer.points_earned )
                {
                    var line_select = this.pos.get_order().get_selected_orderline();
                    line_select.price = 0;
                    line_select.product.reward_points = 0;
                    total_redeem_pts += line_select.product.redeem_points;
                    $(current_order.orderlines.models[0].node).trigger('click');


                }

        },
    });
    screens.define_action_button({

        'name': 'customer_points_redeem_button',
        'widget': PointsRedemptionButton,

    });

//---------------- Order Type Dropdown -----------------
    var OrderTypeDropdownListWidget = screens.ActionButtonWidget.extend({
        template: 'order_type_dropdown',
        button_click: function() {
             var self = this;
             self.ordertype_function();
        },
         ordertype_function: function() {

            var order = this.pos.get_order();
            var this_order = order.name;
            order_type = $(".order_type option:selected").val();
            this.pos.get_order().order_type = String(order_type);



        },

    });
    screens.define_action_button({

        'name': 'order_type_dropdown',
        'widget': OrderTypeDropdownListWidget,
        'condition': function() {
            return this.pos.config.order_type_feat;
        }
    });


//---------------- (+ button) new order button modifier -----------------
    OrderSelectorWidgets.include({
         neworder_click_handler: function(event, $el) {
            this.pos.add_new_order();
            Order_ID=null;
         },
         deleteorder_click_handler: function(event, $el) {
            var self  = this;
            var order = this.pos.get_order();
            if (!order) {
                return;
            } else if ( !order.is_empty() ){
                this.gui.show_popup('confirm',{
                    'title': _t('Destroy Current Order ?'),
                    'body': _t('You will lose any data associated with the current order'),
                    confirm: function(){
                        self.pos.delete_current_order();
                          let order_data = localStorage.getItem('order_value -'+ order.uid);
                           if(order_data)
                           {
                               rpc.query({
                                    model: 'pos.points',
                                    method: 'delete_remove_order',
                                    args: [order.uid],
                               }).then(function(res) {

                               }).catch(function(reason) {
                                    var error = reason.message;
                               });
                               localStorage.removeItem('order_value -'+ order.uid);
                           }
                    },
                });
            } else {
               rpc.query({
                    model: 'pos.points',
                    method: 'delete_remove_order',
                    args: [order.uid],
               }).then(function(res) {

               }).catch(function(reason) {
                    var error = reason.message;
               });
               this.pos.delete_current_order();

            }

    }
    });
//---------------- Product click modifier -----------------
    ProductListWidgets.include({
      init: function(parent, options) {
            var self = this;
            this._super(parent,options);
            var my_order = this.pos.get_order();
            this.click_product_handler = function(){
                var product = self.pos.db.get_product_by_id(this.dataset.productId);
//                var lines = self.pos.db.get_parent_categ_ingredient(4);
//                console.log("test funct",this.pos.config);
//                console.log("product",product);
                options.click_product_action(product);


//                 self.gui.show_popup('Ingredient_Popup_POS', {
//                            'parameter': '',
//                            'confirm': function(value) { },
//                        });

                var current_token=Order_ID;
                var previous_token;
                var current_table=current_table_name;
                var previous_table;
                var current_order = torder;

                if(current_token)
                {
                    if(current_order.table)
                    {
                        if(current_token && current_table)
                        {
                           if(current_token!=previous_token && current_table != previous_table)
                            {
                                rpc.query({

                                    model: 'pos.points',
                                    method: 'check_queue_id',
                                    args: [current_token],
                                }).then(function(q_id) {

                                 var new_product_list={
                                   'queue_id':q_id,
                                   'product_name':product.display_name,
                                   'product_quantity': product.quantity,
                                   'product_category': product.pos_categ_id[1],
                                   'product_colored': product.product_color[1],
                                   'product_message': product.message,
                                   'product_points': product.reward_points,
                                  }
                                  console.log('queue_list',new_product_list);
                                     rpc.query({
                                        model: 'pos.points.line',
                                        method: 'update_queue_order',
                                        args: [new_product_list],
                                    }).then(function() {

                                    }).catch(function(reason) {
                                        var error = reason.message;
                                        console.log(error);
                                    });



                                }).catch(function(reason) {
                                    var error = reason.message;
                                    console.log(error);
                                });

                            }

                             previous_token=current_token;
                             previous_table=current_table;

                        }

                    }
                    else
                    {
                        if(current_token)
                        {
                           if(current_token!=previous_token )
                            {
                                rpc.query({

                                    model: 'pos.points',
                                    method: 'check_queue_id',
                                    args: [current_token],
                                }).then(function(q_id) {
                                 var new_product_list={
                                   'queue_id':q_id,
                                   'product_name':product.display_name,
                                   'product_quantity': product.quantity,
                                   'product_category': product.pos_categ_id[1],
                                   'product_colored': product.product_color[1],
                                   'product_message': product.message,
                                   'product_points': product.reward_points,
                                  }
                                  console.log('queue_list',new_product_list);
                                     rpc.query({
                                        model: 'pos.points.line',
                                        method: 'update_queue_order',
                                        args: [new_product_list],
                                    }).then(function() {

                                    }).catch(function(reason) {
                                        var error = reason.message;
                                        console.log(error);
                                    });



                                }).catch(function(reason) {
                                    var error = reason.message;
                                    console.log(error);
                                });

                            }
                             previous_token=current_token;
                        }
                    }
                }
            }
        },

    });

//---------------- points on order widget -----------------

    PosModel.Order = PosModel.Order.extend({
     get_total_points: function() {
        var total_points =0;
        var orderLines = this.get_orderlines();
        for (var i = 0; i < orderLines.length; i++) {
                    var line = orderLines[i];
                    if(line.product.price != 0)
                    {
                        if (line.product.reward_points > 0) {
                            total_points += round_pr(line.get_quantity() * line.product.reward_points, 1);
                        }
                    }

                }
        return total_points;
  },
     get_total_redeem_points: function(){
        var total_points =0;
        var orderLines = this.get_orderlines();
        for (var i = 0; i < orderLines.length; i++) {
                    var line = orderLines[i];
                        if (line.price == 0) {
                            total_points += round_pr(line.get_quantity() * line.product.redeem_points, 1);
                        }

                }
        return total_points;
     },
    });
    screens.OrderWidget.include({

         update_summary: function(){
            this._super();
            self = this;

            var order = this.pos.get_order();
            var client = this.pos.get_client();
            if (!order.get_orderlines().length) {
                return;
            }

            var total = order ? order.get_total_with_tax() : 0;
            var taxes = order ? total - order.get_total_without_tax() : 0;
            var points   = order ? order.get_total_points() : 0;
            var redeem_points  = order ? order.get_total_redeem_points() : 0;
            var customer_points  = client ? client.points_earned : 0;


            this.el.querySelector('.summary .total > .value').textContent = this.format_currency(total);
            this.el.querySelector('.summary .total .subentry .value').textContent = this.format_currency(taxes);
            this.el.querySelector('.summary .total .subentry .customer_value').textContent = customer_points;
            this.el.querySelector('.summary .total .subentry .point_value').textContent = points;
            this.el.querySelector('.summary .total .subentry .redeem_point_value').textContent = redeem_points;
        },
//         rerender_orderline: function(order_line){
//            this._super(order_line);
//         },

    });




 //---------------- Modifying product widget  * -----------------



    ProductScreenWidgets.include({
        start: function(){
            this._super();
            var self= this;
            var click_catogory_close = $(this.el.childNodes[3].childNodes[1].childNodes[1].childNodes[0].childNodes[1].childNodes[1].childNodes[3].childNodes[1].childNodes[1].childNodes[2])
            if(click_catogory_close)
            {
                $(click_catogory_close).click();
            }
//             var pos_category = this.pos.config.iface_available_categ_ids;
//             var pos_catego = this.pos.db.category_by_id;
//
//             var cat = pos_category[0];
//             console.log(pos_catego);

//             for(var i = 0;i < pos_category.length; i++ )
//             {
//                category_arr.push(pos_category[i]);
//             }
//              var pos_catego_k = this.pos.db;
//              var pos_catego = this.pos.db.category_by_id;
//              var int_id;
//              console.log('haha',pos_catego);
//              console.log('hahakk',pos_catego_k.limit);
//              for(var i = 0; i < pos_catego_k.limit; i ++)
//              {
//                console.log('hahass',pos_catego[i]);
//                if(pos_catego[i])
//                {
//                    if(pos_catego[i].name == "Ingredient")
//                    {
//                        int_id = pos_catego[i].id;
//                    }
//                }
//              }
//              console.log(int_id);

//            console.log("include start ProductScreenWidget for ingredent purpose",pos_category);
//             rpc.query({
//                            model: 'pos.points',
//                            method: 'search_ingredients',
//                            args: [pos_category],
//                        }).then(function(res) {
//                            self.id_return(res);
//                        }).catch(function(reason) {
//                            var error = reason.message;
//                        });
            this.ingredient_list_widget = new ProductListWidgets(this,{
            click_product_action: function(product){ self.click_product(product); },
            product_list: this.pos.db.get_parent_categ_ingredient(0)
        });
//         this.ingredient_list_widget.replace(this.$('.placeholder-IngredientListWidget'));

//        this.product_categories_widget = new ProductCategoriesWidgets(this,{
//            product_list_widget: this.product_list_widget,
//        });
//         console.log("hels", this.product_categories_widget);
//        this.product_categories_widget.replace(this.$('.placeholder-ProductCategoriesWidget'));

         },
        id_return:function(data) { console.log("data",data); int_cate_id = data  },
        show: function(reset){
            this._super(reset);

            fetch_type = $(".order_type option:selected").text().trim();
           console.log('fetch_type',fetch_type);


            var self = this;
            var orders = this.pos.get_order();
            console.log('orders',orders);
            var pos_orders = self.pos.get('selectedOrder');
             console.log('pos_orders',pos_orders);
//            var selected_type = $("input[name='ordertype']:checked").val();
//            console.log('selected_type',selected_type);
            $('.order_type').prop('value',this.pos.get_order().order_type);
            torder = self.pos.get_order();
            pos_table = self.pos.table;
            var pos_orders = self.pos.get('selectedOrder');
            var line = this.pos.get_order().get_selected_orderline();
            pos_info=self.pos.pos_session;
            this.pos.get_order().order_progress = "live";

            if(this.pos.get_client())
            {
                customer_name=this.pos.get_client().name;
            }
            else
            {
                customer_name="";
            }
            if(this.pos.get_order().table)
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                current_table_name = torder.table.name;
                CurrentOrder = customer_name;
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                fetch_status="live";
                shop_name = torder.pos.config.name;

           }
           else
           {
                shop_session_id = this.pos.config.id;
                shop_session_login_number = pos_info.login_number;
                shop_name = torder.pos.config.name;
                CurrentOrder = customer_name;
                current_table_name="";
                length_orderline=torder.orderlines.length;
                Progress = torder.order_progress;
                c_time = torder.creationtime;
                fetch_status="live";
                shop_name = torder.pos.config.name;

           }

            var data_list = { 'order_id' : torder.uid }
            rpc.query({
                    model: 'pos.points',
                    method: 'check_order_db',
                    args: [data_list],
            }).then(function(res) {
                 if(res){
                       console.log("order doesnt exist");

                        torder.order_id=torder.uid;
                        Order_ID =torder.order_id;
                        order_type = $(".order_type option:selected").val();
                        var today = new Date();
                        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
                        var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                        var dateTime = date+' '+time;
                        torder.order_type = order_type;
                        torder.product_list = queue_lines;
                        torder.order_progress = "live";
//                        Swal.fire
//                         ({
//                              icon: 'success',
//                              title: 'Order Created ',
//                              showConfirmButton: false,
//                              timer: 5000,
//                         });
                         PreviousOrder = CurrentOrder;
                         val_list = {
                                's_id':shop_session_id,
                                's_login_number':shop_session_login_number,
                                's_name':shop_name,
                                'table_name': current_table_name,
                                'order_id': Order_ID,
                                'order_type': order_type,
                                'partner_id': customer_name,
                                'pos_order_id': torder.name,
                                'timestamp_order': dateTime,
                                'order_progress': torder.order_progress,
                         };
                         console.log('val_list',val_list);
                         let order_data = localStorage.getItem('order_value -'+ torder.uid);
                         if(!order_data)
                         {
                           var str_data = JSON.stringify(val_list);
                           localStorage.setItem('order_value -' + torder.uid, str_data);
                         }

                        rpc.query({
                            model: 'pos.points',
                            method: 'create_order',
                            args: [val_list],
                        }).then(function(res) {

                        }).catch(function(reason) {
                            var error = reason.message;
                        });


                 }
                 else if(!res)
                 {
                     console.log("order exist");
                    torder.order_id=torder.uid;
                    Order_ID =torder.order_id;
                    order_type = $(".order_type option:selected").val();
                    var today = new Date();
                    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
                    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                    var dateTime = date+' '+time;
                    torder.order_type = order_type;
                    torder.product_list = queue_lines;
                       val_list = {
                                's_id':shop_session_id,
                                's_login_number':shop_session_login_number,
                                's_name':shop_name,
                                'table_name': current_table_name,
                                'order_id': Order_ID,
                                'order_type': order_type,
                                'partner_id': customer_name,
                                'pos_order_id': torder.name,
                                'timestamp_order': dateTime,
                                'order_progress': torder.order_progress,
                         };
                            console.log('val_list',val_list);
                      rpc.query({
                                    model: 'pos.points',
                                    method: 'update_order_info',
                                    args: [val_list],
                                }).then(function(res) {
                                }).catch(function(reason) {
                                    var error = reason.message;
                                });
                 }
            }).catch(function(reason) {
                var error = reason.message;
            });


        },
 });

    ProductCategoriesWidgets.include({

    init: function(parent, options){
        this._super(parent,options);

        },

    renderElement: function(){

        var el_str  = QWeb.render(this.template, {widget: this});
        var el_node = document.createElement('div');

        el_node.innerHTML = el_str;
        el_node = el_node.childNodes[1];

//        if(this.el && this.el.parentNode){
//            this.el.parentNode.replaceChild(el_node,this.el);
//        }

        this.el = el_node;

        var withpics = this.pos.config.iface_display_categ_images;

        var list_container = el_node.querySelector('.category-list');


        if (list_container) {
            if (!withpics) {
                list_container.classList.add('simple');
            } else {
                list_container.classList.remove('simple');
            }
            for(var i = 0, len = this.subcategories.length; i < len; i++){
                list_container.appendChild(this.render_category(this.subcategories[i],withpics));
            }
        }


        var buttons = el_node.querySelectorAll('.js-category-switch');

        for(var i = 0; i < buttons.length; i++){

                 buttons[i].addEventListener('click',this.switch_category_handler)


        }


        var products = this.pos.db.get_product_by_category(this.category.id);
        var example_products = this.pos.db;

        console.log('product list on category click',example_products);

        if(products[0].seq_num !== undefined) {
              console.log('we have field',products[0]);
              var count = 0;
              for(var i = 0; i < products.length; i++){

                    //set min to the current iteration of i
                    var max = i;
                    for(var j = i+1; j < products.length; j++){
                      if(products[j].seq_num > products[max].seq_num){
                       max = j;
                      }
                    }
                    var temp = products[i];
                    products[i] = products[max];
                    products[max] = temp;

            }
              console.log('desc list',products);
              var with_seq_index =[]
              for(var i = 0; i < products.length; i++){
                if(products[i].seq_num > 0)
                {
                    console.log('nav in desc list',products[i]);
                    with_seq_index.push(i)

                }
              }
              console.log('index list of non zero seq_no.  index',with_seq_index);
              for(var i = 0; i < with_seq_index.length; i++){
                 var min = i;
                    for(var j = i+1; j < with_seq_index.length; j++){
                      if(products[j].seq_num < products[min].seq_num){
                       min = j;
                      }
                    }
                    var temp = products[i];
                    products[i] = products[min];
                    products[min] = temp;
              }

        }
        console.log('there is a sequence !!!',products);
        this.product_list_widget.set_product_list(products); // FIXME: this should be moved elsewhere ...

        try{
             console.log('error1');
              var ingredients=this.pos.db.get_parent_categ_ingredient(this.category.id);
              if(ingredients)
              {
                 console.log('error1');
                 this.ingredient_list_widget =   new ProductListWidgets(this,{
                        click_product : function(product) {
                         console.log("current product",product);console.log("current ",this);
                       if(product.to_weight && this.pos.config.iface_electronic_scale){
                           this.gui.show_screen('scale',{product: product});
                       }else{
                             torder.add_product(product);
                       }
               },
                        click_product_action:  function(product){ this.click_product(product); } ,
                        product_list: ingredients
                   });
                this.ingredient_list_widget.el=this.__parentedParent.$el[0].childNodes[3].childNodes[1].childNodes[1].childNodes[2].childNodes[1].childNodes[3].childNodes[1]
                this.ingredient_list_widget.set_product_list(ingredients);

              }

        }
        catch
        {
            console.log('catch');
        }


        this.el.querySelector('.searchbox input').addEventListener('keypress',this.search_handler);

        this.el.querySelector('.searchbox input').addEventListener('keydown',this.search_handler);

        this.el.querySelector('.search-clear.right').addEventListener('click',this.clear_search_handler);

        if(this.pos.config.iface_vkeyboard && this.chrome.widget.keyboard){
            this.chrome.widget.keyboard.connect($(this.el.querySelector('.searchbox input')));
        }
    },

 });

 //---------------- Modifying next after validation widget  * -----------------

    screens.ReceiptScreenWidget.include({
        click_next: function(ev) {
            this._super();
            $('.order_type').prop('selectedIndex',0);
//              self.gui.show_popup('Ordertype_Popup_POS', {
//                            'parameter': '',
//                            'confirm': function(value) { },
//              });
        }
    });


 //---------------- Modifying orderselection widget -----------------
    OrderSelectorWidgets.include({

         neworder_click_handler: function(event, $el) {
            this.pos.add_new_order();
            $('.order_type').prop('selectedIndex',0);
//            self.gui.show_popup('Ordertype_Popup_POS', {
//                            'parameter': '',
//                            'confirm': function(value) { },
//              });
             this.pos.get_order().redeem_pt=0;
//               popup_open = false;

         },
         floor_button_click_handler: function(){
                this.pos.set_table(null);
                $('.order_type').prop('selectedIndex',0);
        },
    });


//---------------- modifying select customer button on POS -----------------

    ClientListScreenWidget.include({
        save_changes: function() {
            this._super();
            var sel_customer= this.pos.get_client();
            var point_limit = this.pos.config.points_cap;
            if(sel_customer)
            {
                if(sel_customer.points_earned >= point_limit)
                {
                     Swal.fire
                           ({
                                  icon: 'info',
                                  title: 'Points are eligible for redemption',
                                  text: "Dear " + sel_customer.name + " Congratulation ! These Products are FREE to get against your loyalty points",
                                  showConfirmButton: false,
                                  timer: 2000
                           });
    //                 popup_open=false;
                }
            }
        },



});



//---------------- Pay button check -----------------
    screens.ActionpadWidget.include({
      renderElement: function() {
            this._super();
            var self = this;

                this.$('.pay').click(function(){
                    if(saved_o==1)
                    {
                        var order = self.pos.get_order();
                        if(!order.get_client())
                        {

                            Swal.fire
                               ({
                                      icon: 'warning',
                                      title: 'Customer not selected',
                                      text: "You won't be able earn points for current transaction!",
                                      showConfirmButton: false,
                                      timer: 1000
                               });
                        }
                    }
                    else
                    {
                        self.gui.show_screen('products');
                        Swal.fire
                               ({
                                      icon: 'warning',
                                      title: 'Order Not saved',
                                      text: "Data of the order will not be saved !",
                                      showConfirmButton: false,
                                      timer: 2000
                               });
                    }

                });

      }
    });

});
