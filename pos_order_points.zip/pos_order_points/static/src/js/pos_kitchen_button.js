
 $(function(){

            var token_don;
            var token_pro;

            $(".button_submitt").click(function(){
              token_don = $(this).parent().next().find("#token_num").val();
              var input_data = {
                token_num: token_don,
            };
            var options = {
                url: '/pos_order_points/token_isdone',
                data: input_data ,
                dataType:'JSON',
                success: function(data){
                    if(typeof(data) == 'string')
                    {
                    }
                },
                error:function(a){
                }

            };
            $.ajax(options);
            location.reload();
            });

       }
 );
