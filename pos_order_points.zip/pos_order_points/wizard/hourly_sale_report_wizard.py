from odoo import fields, models
from datetime import datetime


class HourlySaleReportWizard(models.TransientModel):
    _name = 'hourly.sale.report.wizard'
    _description = 'Hourly POS Sale Report'

    date_h = fields.Date("Date")

    def check_report(self):
        self.ensure_one()
        total_sale = 0

        report_list = {}
        now = datetime.now()
        print('now', now)
        # date_time_strt_all = now.replace(hour=0, minute=0, second=0, microsecond=0)
        # date_time_finish_all = now.replace(hour=23, minute=59, second=59, microsecond=0)
        input_date = self.date_h
        input_date_str = datetime.strftime(self.date_h, '%Y-%m-%d')
        print(input_date_str)
        date_time_strt_all_str = "00:00:00" + " " + input_date_str
        date_time_finish_all_str = "23:59:59" + " " + input_date_str
        date_time_strt_all = datetime.strptime(date_time_strt_all_str, '%H:%M:%S %Y-%m-%d')
        date_time_finish_all = datetime.strptime(date_time_finish_all_str, '%H:%M:%S %Y-%m-%d')

        print(date_time_strt_all)
        print(date_time_finish_all)
        vals = {}

        sales0 = 0
        sales1 = 0
        sales2 = 0
        sales3 = 0
        sales4 = 0
        sales5 = 0
        sales6 = 0
        sales7 = 0
        sales8 = 0
        sales9 = 0
        sales10 = 0
        sales11 = 0
        sales12 = 0
        sales13 = 0
        sales14 = 0
        sales15 = 0
        sales16 = 0
        sales17 = 0
        sales18 = 0
        sales19 = 0
        sales20 = 0
        sales21 = 0
        sales22 = 0
        sales23 = 0


        unit0 = 0
        unit1 = 0
        unit2 = 0
        unit3 = 0
        unit4 = 0
        unit5 = 0
        unit6 = 0
        unit7 = 0
        unit8 = 0
        unit9 = 0
        unit10 = 0
        unit11 = 0
        unit12 = 0
        unit13 = 0
        unit14 = 0
        unit15 = 0
        unit16 = 0
        unit17 = 0
        unit18 = 0
        unit19 = 0
        unit20 = 0
        unit21 = 0
        unit22 = 0
        unit23 = 0

        date_time_strt_1 = now.replace(hour=0, minute=0, second=0, microsecond=0)
        date_time_strt_2 = now.replace(hour=1, minute=0, second=0, microsecond=0)
        date_time_strt_3 = now.replace(hour=2, minute=0, second=0, microsecond=0)
        date_time_strt_4 = now.replace(hour=3, minute=0, second=0, microsecond=0)
        date_time_strt_5 = now.replace(hour=4, minute=0, second=0, microsecond=0)
        date_time_strt_6 = now.replace(hour=5, minute=0, second=0, microsecond=0)
        date_time_strt_7 = now.replace(hour=6, minute=0, second=0, microsecond=0)
        date_time_strt_8 = now.replace(hour=7, minute=0, second=0, microsecond=0)
        date_time_strt_9 = now.replace(hour=8, minute=0, second=0, microsecond=0)
        date_time_strt_10 = now.replace(hour=9, minute=0, second=0, microsecond=0)
        date_time_strt_11 = now.replace(hour=10, minute=0, second=0, microsecond=0)
        date_time_strt_12 = now.replace(hour=11, minute=0, second=0, microsecond=0)
        date_time_strt_13 = now.replace(hour=12, minute=0, second=0, microsecond=0)
        date_time_strt_14 = now.replace(hour=13, minute=0, second=0, microsecond=0)
        date_time_strt_15 = now.replace(hour=14, minute=0, second=0, microsecond=0)
        date_time_strt_16 = now.replace(hour=15, minute=0, second=0, microsecond=0)
        date_time_strt_17 = now.replace(hour=16, minute=0, second=0, microsecond=0)
        date_time_strt_18 = now.replace(hour=17, minute=0, second=0, microsecond=0)
        date_time_strt_19 = now.replace(hour=18, minute=0, second=0, microsecond=0)
        date_time_strt_20 = now.replace(hour=19, minute=0, second=0, microsecond=0)
        date_time_strt_21 = now.replace(hour=20, minute=0, second=0, microsecond=0)
        date_time_strt_22 = now.replace(hour=21, minute=0, second=0, microsecond=0)
        date_time_strt_23 = now.replace(hour=22, minute=0, second=0, microsecond=0)
        date_time_strt_24 = now.replace(hour=23, minute=0, second=0, microsecond=0)
        date_time_strt_25 = now.replace(hour=23, minute=59, second=0, microsecond=0)

        date_order = self.env['pos.order'].search([('date_order', '>=', date_time_strt_all), ('date_order', '<=', date_time_finish_all)])
        date_order1 = self.env['pos.order'].search([('name', '=', 'Shop/0116')])
        print(date_order1.date_order)
        print(date_order)
        if date_order:
            print('no of orders', len(date_order))
            for all_orders in date_order:
                # print('all order: - ',all_orders.date_order.time())
                # adad = str(all_orders.date_order.time())
                print('break at ->', all_orders.name)
                if date_time_strt_1.time() < all_orders.date_order.time() < date_time_strt_2.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales0 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit0 += line.qty
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                if date_time_strt_2.time() < all_orders.date_order.time() < date_time_strt_3.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales1 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit1 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_3.time() < all_orders.date_order.time() < date_time_strt_4.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales2 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit2 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_4.time() < all_orders.date_order.time() < date_time_strt_5.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales3 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit3 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_5.time() < all_orders.date_order.time() < date_time_strt_6.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales4 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit4 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                if date_time_strt_6.time() < all_orders.date_order.time() < date_time_strt_7.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales5 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit5 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                if date_time_strt_7.time() < all_orders.date_order.time() < date_time_strt_8.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales6 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit5 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_8.time() < all_orders.date_order.time() < date_time_strt_9.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales7 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit6 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_9.time() < all_orders.date_order.time() < date_time_strt_10.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales8 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit7 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_10.time() < all_orders.date_order.time() < date_time_strt_11.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales9 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit9 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_11.time() < all_orders.date_order.time() < date_time_strt_12.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales10 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit10 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_12.time() < all_orders.date_order.time() < date_time_strt_13.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales11 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit11 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_13.time() < all_orders.date_order.time() < date_time_strt_14.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales12 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit12 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_14.time() < all_orders.date_order.time() < date_time_strt_15.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales13 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit13 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_15.time() < all_orders.date_order.time() < date_time_strt_16.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales14 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit14 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_16.time() < all_orders.date_order.time() < date_time_strt_17.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales15 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit15 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_17.time() < all_orders.date_order.time() < date_time_strt_18.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales16 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit16 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_18.time() < all_orders.date_order.time() < date_time_strt_19.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales17 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit17 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_19.time() < all_orders.date_order.time() < date_time_strt_20.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales18 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit18 += line.qty
                    report_list[all_orders.date_order.time()]=total_sale
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                if date_time_strt_20.time() < all_orders.date_order.time() < date_time_strt_21.time():
                    # print('order: ', all_orders.date_order.time(),'Total =', total_sale)
                    sales19 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit19 += line.qty
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})

                if date_time_strt_21.time() < all_orders.date_order.time() < date_time_strt_22.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales20 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit20 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

                if date_time_strt_22.time() < all_orders.date_order.time() < date_time_strt_23.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales21 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit21 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                if date_time_strt_23.time() < all_orders.date_order.time() < date_time_strt_24.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales22 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit22 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale
                if date_time_strt_24.time() < all_orders.date_order.time() < date_time_strt_25.time():
                    # print('order: ', all_orders.date_order.time(), 'Total =', total_sale)
                    sales23 += all_orders.amount_total
                    for line in all_orders.lines:
                        unit23 += line.qty
                    # report_list.append({"order": all_orders.date_order.time(), 'total sale': total_sale})
                    date_time_current_all = datetime.strftime(all_orders.date_order, '%H:%M:%S')
                    report_list[date_time_current_all] = total_sale

        print(report_list)
        vals = {
            'date' : datetime.strftime(self.date_h, '%d/%m/%Y'),
            'sales0' : sales0,
            'sales1' : sales1,
            'sales2' : sales2,
            'sales3' : sales3,
            'sales4' : sales4,
            'sales5' : sales5,
            'sales6' : sales6,
            'sales7' : sales7,
            'sales8' : sales8,
            'sales9' : sales9,
            'sales10' : sales10,
            'sales11' : sales11,
            'sales12' : sales12,
            'sales13' : sales13,
            'sales14' : sales14,
            'sales15' : sales15,
            'sales16' : sales16,
            'sales17' : sales17,
            'sales18' : sales18,
            'sales19' : sales19,
            'sales20' : sales20,
            'sales21' : sales21,
            'sales22' : sales22,
            'sales23' : sales23,
            'unit0': unit0,
            'unit1': unit1,
            'unit2': unit2,
            'unit3': unit3,
            'unit4': unit4,
            'unit5': unit5,
            'unit6': unit6,
            'unit7': unit7,
            'unit8': unit8,
            'unit9': unit9,
            'unit10': unit10,
            'unit11': unit11,
            'unit12': unit12,
            'unit13': unit13,
            'unit14': unit14,
            'unit15': unit15,
            'unit16': unit16,
            'unit17': unit17,
            'unit18': unit18,
            'unit19': unit19,
            'unit20': unit20,
            'unit21': unit21,
            'unit22': unit22,
            'unit23': unit23

        }
        print(vals)

        return self.env.ref('pos_order_points.custom_hourly_pos_sale_report').report_action(self, data=vals)
