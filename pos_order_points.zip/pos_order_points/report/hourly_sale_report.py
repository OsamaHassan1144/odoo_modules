from odoo import models, api
from odoo.exceptions import UserError


class HourlySaleReport(models.AbstractModel):
    _name = 'pos_order_points.hourly_sale_report'
    _description = 'Hourly Order Sale Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'data': data,
        }
