# -*- coding: utf-8 -*-
from odoo import http
from datetime import datetime


class PosToken(http.Controller):
    @http.route('/<s_name>/orderqueuelist/', auth='user')
    def token_scr(self, s_name):
        data = http.request.env['pos.points'].search(
            [('order_progress', 'in', ('open', 'final', 'closed')), ('s_name', '=', s_name)])
        return http.request.render('pos_order_points.order_details_page', {
            'object': data
        })

    @http.route('/<s_name>/bumpscreen/', auth='user')
    def kitchen_side_token_scr(self, s_name):
        data = http.request.env['pos.points'].search(
            [('order_progress', 'in', ('live', 'open', 'final')), ('s_name', '=', s_name)])
        res = http.request.render('pos_order_points.order_kitchenside_page', {
            'objects': data
        })
        return res
        # for x in data:
        #     if x.order_progress == 'live':
        #         res = http.request.render('pos_order_points.order_kitchenside_page', {
        #             'objectsL': data
        #         })
        #         return res
        #     elif x.order_progress == 'open':
        #         res = http.request.render('pos_order_points.order_kitchenside_page', {
        #             'objectsO': data
        #         })
        #         return res
        #     elif x.order_progress == 'final':
        #         res = http.request.render('pos_order_points.order_kitchenside_page', {
        #             'objectsF': data
        #         })
        #         return res

    @http.route('/pos_order_points/token_isdone', auth='user')
    def update_kitchen_done(self, **kw):
        tok = kw['token_num']
        res = http.request.env['pos.points'].search([('order_id', '=', tok)])
        res.order_progress = 'closed'
        res.o_status = 'prepared'
        x = datetime.now()
        res.p_end = x

    @http.route('/pos_order_points/token_progress', auth='user')
    def update_kitchen_in_progress(self, **kw):
        tok = kw['orderid']
        res = http.request.env['pos.points'].search([('order_id', '=', tok)])
        res.order_progress = 'final'
        res.o_status = 'preparing'
        x = datetime.now()
        res.p_start = x
