# -*- coding: utf-8 -*-


from odoo import api, fields, models, http
from datetime import datetime


class POSOrderQueue(models.Model):
    _name = 'pos.points'

    _rec_name = 'pos_order_id'

    s_name = fields.Char(string="Session Name", store=True)
    s_id = fields.Integer(string="Session Number", store=True)
    s_login_number = fields.Integer(string="Session Login Number", store=True)
    order_id = fields.Char(string="order id", store=True)
    table_name = fields.Char(string="Table Name", store=True)
    order_type = fields.Selection([('drivethru', 'Drive-thru'),
                                   ('straightcar', 'Straight car'),
                                   ('walkout', 'Walk out')], string="Order Type", store=True)
    partner_id = fields.Char(store=True)
    p_start = fields.Datetime(string='Preparing started at', store=True)
    p_end = fields.Datetime(string='Prepared at', store=True)
    o_status = fields.Selection([('preparing', 'Preparing'), ('prepared', 'Prepared')], string="Order status",
                                store=True)
    pos_order_id = fields.Char(store=True)
    timestamp_order = fields.Char(string='Order\'s Time Stamp', store=True)
    order_progress = fields.Selection([('closed', 'Closed'), ('final', 'Final'),
                                       ('open', 'Open'),
                                       ('live', 'Live')], string="Order progress", default='live', store=True)
    no_items = fields.Integer(string='No of Items', store=True)
    queue_line_ids = fields.One2many('pos.points.line', 'queue_id')

    @api.model
    def create_order(self, val_list):
        res = super(POSOrderQueue, self).create(val_list)
        return res.id

    @api.model
    def check_order_db(self, val_list):
        res = http.request.env['pos.points'].search([('order_id', '=', val_list['order_id'])])
        if res:
            print('order exist')
            return False
        else:
            print('order doesn\'t exist')
            return True

    @api.model
    def update_order_info(self, hellos):
        res = http.request.env['pos.points'].search([('order_id', '=', hellos['order_id'])])
        if res:
            res = super(POSOrderQueue, res).update(hellos)


    @api.model
    def search_ingredients(self, my_arr):
        res = http.request.env['pos.category'].search([])
        for y in res:
            for x in my_arr:
                if x == y.id:
                    if y.name == 'ingredient' or y.name == 'Ingredient':
                        return y.id

    @api.model
    def update_order(self, hellos):
        res = http.request.env['pos.points'].search([('order_id', '=', hellos['order_id'])])
        if res:
            return res.id

    @api.model
    def update_order_status(self, hellos):
        res = http.request.env['pos.points'].search([('order_id', '=', hellos['order_id'])])
        res.order_progress = "open"
        res.partner_id = hellos['partner_id']
        res.order_type = hellos['order_type']
        return res.id

    @api.model
    def check_order_status(self, hello):
        res = http.request.env['pos.points'].search([('order_id', '=', hello)])
        return res.order_progress

    @api.model
    def check_queue_id(self, hellos):
        res = http.request.env['pos.points'].search([('order_id', '=', hellos)])
        return res.id

    @api.model
    def validate_order_timestamp(self, halo):
        res = http.request.env['pos.points'].search([('order_id', '=', halo['orderid'])])
        now = datetime.strftime(datetime.now(), "%y-%m-%d %H:%M:%S")
        res.timestamp_order = now
        print('timestamp=>', res.timestamp_order)

    @api.model
    def delete_remove_order(self, order_ref):
        print("removing id get ", order_ref)
        res = http.request.env['pos.points'].search([('order_id', '=', order_ref)])
        print("removing", res)
        if res:
            res.unlink()

    @api.model
    def _generate_order_by(self, order_spec, query):
        my_order = "CASE WHEN order_progress='final'  THEN 0   WHEN order_progress = 'open'  THEN 1 ELSE 2 END"
        if order_spec:
            return super(POSOrderQueue, self)._generate_order_by(order_spec, query) + ", " + my_order
        return " order by " + my_order

    # @api.model
    # def fetch_int_cate(self):
    #     print('fetching int category id')
    #     res = http.request.env['pos.category'].search(['name','=',])
    #     for x in res:
    #         print("x", x.name, "id",x.id)


class POSOrderQueueLine(models.Model):
    _name = 'pos.points.line'

    queue_id = fields.Many2one('pos.points')
    product_name = fields.Char(store=True)
    product_category = fields.Char(store=True)
    product_message = fields.Char(store=True)
    product_points = fields.Integer(store=True)
    product_quantity = fields.Integer(store=True)
    product_colored = fields.Char(store=True)

    @api.model
    def create_queue_order(self, val_list):
        que = self.env['pos.points'].search([('id', '=', val_list['queue_id'])])
        pue = self.env['pos.points.line'].search(
            [('queue_id', '=', val_list['queue_id']), ('product_name', '=', val_list['product_name'])])
        if pue:
            prod = self.env['product.product'].search([('name', '=', val_list['product_name'])])
            if not prod.distinct_product:
                pue.product_message = val_list['product_message']
                pue.product_colored = val_list['product_colored']
            else:
                if que:
                    val_list['queue_id'] = ""
                res = super(POSOrderQueueLine, self).create(val_list)
                res.queue_id = que
                return res
        else:
            if que:
                val_list['queue_id'] = ""
            res = super(POSOrderQueueLine, self).create(val_list)
            res.queue_id = que
            return res

    @api.model
    def update_queue_order(self, new_product_list):
        que = self.env['pos.points'].search([('id', '=', new_product_list['queue_id'])])
        prod = self.env['product.product'].search([('name', '=', new_product_list['product_name'])])
        if not prod.distinct_product:
            pue = self.env['pos.points.line'].search(
                [('queue_id', '=', new_product_list['queue_id']),
                 ('product_name', '=', new_product_list['product_name'])])
            if pue:
                pue.product_quantity += 1
                try:
                    pue.product_colored = new_product_list['product_colored']
                except:
                    pue.product_colored = " "
                pue.product_points = int(new_product_list['product_points']) * pue.product_quantity
                print('points of addition =>', pue.product_points)
            else:
                new_product_list['queue_id'] = ""
                res = super(POSOrderQueueLine, self).create(new_product_list)
                res.product_quantity = 1
                res.product_colored = res.product_colored
                res.product_points = res.product_points
                res.queue_id = que
                return res
        else:
            new_product_list['queue_id'] = ""
            res = super(POSOrderQueueLine, self).create(new_product_list)
            res.product_quantity = 1
            res.product_colored = res.product_colored
            res.product_points = res.product_points
            res.queue_id = que
            return res

    @api.model
    def update_existing_lines(self, vals_list):
        que = self.env['pos.points'].search([('id', '=', vals_list[0]['queue_id'])])
        if que:
            lines = que.queue_line_ids
            lines.unlink()
            for line in vals_list:
                line['queue_id'] = ""
                res = super(POSOrderQueueLine, self).create(line)
                res.queue_id = que
                # return res


class PointsSystemProduct(models.Model):
    _inherit = 'product.product'

    reward_points = fields.Integer(string="Points", store=True, default=0)
    redeem_points = fields.Integer(string="Redemption Points", store=True, default=0)
    seq_num = fields.Integer(string="In POS seq no.", store=True)
    instruction_select = fields.Many2many('pos.message', String="Select instruction")
    distinct_product = fields.Boolean(string="Distinct Item on POS Order", store=True)
    parent_int_categ = fields.Many2many('pos.category', string="Ingredient's Parent Category", store=True)


class PointsSystemCustomer(models.Model):
    _inherit = 'res.partner'

    points_earned = fields.Integer(string="Points Earned", store=True, default=0)
    car_num = fields.Char(string="Car #", store=True, )

    @api.model
    def updating_points(self, data):
        que = self.env['res.partner'].search([('name', '=', data['customer_name'])])
        print(que.car_num)
        que.points_earned = data['update_points']


class points_redemption(models.Model):
    _name = 'point.redeem'
    _rec_name = 'logic_name'

    points_qty = fields.Integer(string="Points assigned", store=True)
    logic_name = fields.Char(string="Redemption Logic", store=True)


class pos_seq(models.Model):
    _inherit = 'pos.config'

    order_type_feat = fields.Boolean(default=False, string="Order Type Option")
    points_cap = fields.Integer(default=False, store=True, string="Points Cap.")
    redemption_logic = fields.Many2one('point.redeem')
    # pos_type_sel = fields.Selection([('simple', 'Simple'), ('drivethru', 'Drive Thru'), ('oil_rest_hotel', 'Oil/Restaurant/Hotel')],
    #                                 string="Pos Type", default='simp')


class message_product(models.Model):
    _name = 'pos.message'

    msg_text = fields.Text(string="Instruction Content", store=True, default=" ")

    @api.model
    def get_all_messages(self):
        res = self.env['pos.message'].search([])
        list_msg = []
        for x in res:
            data_list = {
                'id': x.id,
                'msg_text': x.msg_text
            }
            list_msg.append(data_list)
        print("list_msg", list_msg)
        return list_msg
